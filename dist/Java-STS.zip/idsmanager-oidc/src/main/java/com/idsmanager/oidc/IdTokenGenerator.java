package com.idsmanager.oidc;


import org.jose4j.json.JsonUtil;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.NumericDate;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.PrivateKey;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;


/**
 * 2016/11/3
 * <p/>
 * <p/>
 * 生成 id_token
 *
 * @author Shengzhao Li
 */
public class IdTokenGenerator {

    /**
     * 默认的id_token有效时间: 10分钟
     */
    public static final long DEFAULT_TOKEN_SECONDS = 600L;


    /**
     * 默认的 Audience
     */
    public static final String DEFAULT_AUDIENCE = "IDS_AUDIENCE";

    /**
     * 默认的 Subject
     */
    public static final String DEFAULT_SUBJECT = "IDS_Subject";

    /**
     * 默认生成时使用的算法
     */
    public static final String DEFAULT_ALGORITHM = AlgorithmIdentifiers.RSA_USING_SHA256;


    private static final Logger LOG = LoggerFactory.getLogger(IdTokenGenerator.class);


    protected String algorithm = DEFAULT_ALGORITHM;

    protected String keyId;

    /**
     * 两种类型的 private key
     */
    protected String privateKeyJson;
    protected PrivateKey privateKey;

    /**
     * 不同类型的 claims 数据
     */
    protected Map<String, Object> map = new HashMap<>();
    protected JwtClaims claims;


    public IdTokenGenerator(String privateKeyJson, Map<String, Object> map) {
        this.privateKeyJson = privateKeyJson;
        this.map = map;
    }

    public IdTokenGenerator(String privateKeyJson, JwtClaims claims) {
        this.privateKeyJson = privateKeyJson;
        this.claims = claims;
    }

    public IdTokenGenerator(PrivateKey privateKey, Map<String, Object> map) {
        this.privateKey = privateKey;
        this.map = map;
    }

    public IdTokenGenerator(PrivateKey privateKey, JwtClaims claims) {
        this.privateKey = privateKey;
        this.claims = claims;
    }

    /**
     * 设置使用的算法
     *
     * @param algorithm {@link org.jose4j.jws.AlgorithmIdentifiers#RSA_USING_SHA256},
     *                  {@link org.jose4j.jws.AlgorithmIdentifiers#RSA_USING_SHA384},
     *                  {@link org.jose4j.jws.AlgorithmIdentifiers#RSA_PSS_USING_SHA512} and so on
     */
    public IdTokenGenerator algorithm(String algorithm) {
        this.algorithm = algorithm;
        return this;
    }

    /*
    * 设置使用的keyId
    * */
    public IdTokenGenerator keyId(String keyId) {
        this.keyId = keyId;
        return this;
    }

    /**
     * 生成 id_token
     */
    public String generate() throws JoseException {

        final String keyId = getRealKeyId();

        JwtClaims claims = getJwtClaims();
        JsonWebSignature jws = getJsonWebSignature(keyId, claims);

        return getIdToken(jws);
    }


    /*
     * 获取在运行时真实的 keyId
     * @return
     * @throws JoseException
     */
    protected String getRealKeyId() throws JoseException {
        if (this.keyId != null && this.keyId.length() > 0) {
            return this.keyId;
        }
        if (this.privateKeyJson != null) {
            JsonWebKey jsonWebKey = JsonWebKey.Factory.newJwk(this.privateKeyJson);
            return jsonWebKey.getKeyId();
        }

        this.keyId = UUID.randomUUID().toString();
        LOG.debug("Use random keyId: {}", this.keyId);
        return this.keyId;
    }


    /**
     * 从 JsonWebSignature 从获取  id_token
     *
     * @param jws JsonWebSignature
     * @return idToken
     * @throws org.jose4j.lang.JoseException
     */
    protected String getIdToken(JsonWebSignature jws) throws JoseException {
        return jws.getCompactSerialization();
    }

    /**
     * 获取 JsonWebSignature
     *
     * @param keyId  keyId
     * @param claims JwtClaims
     * @return JsonWebSignature
     * @throws org.jose4j.lang.JoseException
     */
    protected JsonWebSignature getJsonWebSignature(String keyId, JwtClaims claims) throws JoseException {
        JsonWebSignature jws = createJsonWebSignature();
        setJsonWebSignaturePayload(claims, jws);

        setJsonWebSignaturePrivateKey(jws);
        jws.setKeyIdHeaderValue(keyId);
        return jws;
    }


    /**
     * 创建 JsonWebSignature
     *
     * @return JsonWebSignature
     */
    protected JsonWebSignature createJsonWebSignature() {
        JsonWebSignature jws = new JsonWebSignature();
        jws.setAlgorithmHeaderValue(this.algorithm);
        return jws;
    }

    /**
     * 设置 JsonWebSignature 中的 Payload
     *
     * @param claims JwtClaims
     * @param jws    JsonWebSignature
     */
    protected void setJsonWebSignaturePayload(JwtClaims claims, JsonWebSignature jws) {
        jws.setPayload(claims.toJson());
    }


    /**
     * 设置 JsonWebSignature 中的 privateKey
     *
     * @param jws JsonWebSignature
     * @throws org.jose4j.lang.JoseException JoseException
     */
    protected void setJsonWebSignaturePrivateKey(JsonWebSignature jws) throws JoseException {
        if (this.privateKey != null) {
            jws.setKey(this.privateKey);
        } else {
            final Map<String, Object> params = JsonUtil.parseJson(privateKeyJson);
            PrivateKey privateKey = new RsaJsonWebKey(params).getPrivateKey();
            jws.setKey(privateKey);
        }
    }


    /**
     * 获取 JwtClaims
     *
     * @return JwtClaims
     */
    protected JwtClaims getJwtClaims() {
        if (this.claims != null) {
            return this.claims;
        }
        JwtClaims claims = new JwtClaims();
        setIdTokenExpirationTime(claims);
        setAudience(claims);
        setSubject(claims);

        claims.setGeneratedJwtId();
        claims.setIssuedAtToNow();
        //past 1 minute
        claims.setNotBeforeMinutesInThePast(1);

        setMoreClaims(claims);

        setClaimsMap(claims);

        return claims;
    }

    /**
     * 设置 用户传入的 claimMap
     *
     * @param claims JwtClaims
     */
    protected void setClaimsMap(JwtClaims claims) {
        if (this.map != null) {
            final Set<String> set = this.map.keySet();
            for (String key : set) {
                claims.setClaim(key, this.map.get(key));
            }
        }
    }


    /**
     * 扩展, 用于子类 设置 更多  JwtClaims 中的属性
     *
     * @param claims JwtClaims
     */
    protected void setMoreClaims(JwtClaims claims) {
    }


    /**
     * 设置 JwtClaims 中的  Subject
     *
     * @param claims JwtClaims
     */
    protected void setSubject(JwtClaims claims) {
        claims.setSubject(getSubject());
    }


    /**
     * 获取 JwtClaims中的 Subject
     *
     * @return Audience
     */
    protected String getSubject() {
        return DEFAULT_SUBJECT;
    }


    /**
     * 设置 JwtClaims 中的  Audience
     *
     * @param claims JwtClaims
     */
    protected void setAudience(JwtClaims claims) {
        claims.setAudience(getAudience());
    }


    /**
     * 获取 JwtClaims中的 Audience
     *
     * @return Audience
     */
    protected String getAudience() {
        return DEFAULT_AUDIENCE;
    }


    /**
     * 设置　id_token 过期时间
     *
     * @param claims JwtClaims
     */
    protected void setIdTokenExpirationTime(JwtClaims claims) {
        // expire time
        NumericDate date = NumericDate.now();
        date.addSeconds(getIdTokenSeconds());
        claims.setExpirationTime(date);
    }


    /**
     * id_token的 有效时长, 单位:秒
     *
     * @return Seconds of id_token
     */
    protected long getIdTokenSeconds() {
        return DEFAULT_TOKEN_SECONDS;
    }


}
