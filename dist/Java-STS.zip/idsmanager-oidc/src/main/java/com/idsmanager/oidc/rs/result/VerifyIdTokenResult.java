package com.idsmanager.oidc.rs.result;

import java.util.HashMap;
import java.util.Map;

/**
 * 2016/10/11
 * <p/>
 * 验证id_token 的结果
 *
 * @author Ling
 */
public class VerifyIdTokenResult extends APIResult {
    private static final long serialVersionUID = -954889378914485551L;

    /*
    * 验证idToken 成功后 获取的 Map信息
    * */
    private Map<String, Object> claimsMap = new HashMap<String, Object>();


    public VerifyIdTokenResult(int statusCode, String error) {
        super(statusCode, error);
    }

    /**
     * Construct from APIResult
     *
     * @param apiResult APIResult
     */
    public VerifyIdTokenResult(APIResult apiResult) {
        this.statusCode = apiResult.getStatusCode();
        this.errors = apiResult.getErrors();
    }

    public VerifyIdTokenResult(Map<String, Object> claimsMap) {
        this.claimsMap = claimsMap;
    }

    public Map<String, Object> getClaimsMap() {
        return claimsMap;
    }

    public void setClaimsMap(Map<String, Object> claimsMap) {
        this.claimsMap = claimsMap;
    }

    @Override
    public String toString() {
        return "{" +
                "claimsMap=" + claimsMap +
                ", statusCode=" + statusCode +
                ", errors=" + errors +
                '}';
    }
}
