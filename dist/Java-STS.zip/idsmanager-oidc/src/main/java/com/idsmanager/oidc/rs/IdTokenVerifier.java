package com.idsmanager.oidc.rs;


import com.idsmanager.oidc.rs.result.VerifyIdTokenResult;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.NumericDate;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.PublicKey;
import java.util.Map;

import static com.idsmanager.oidc.Constants.*;

/**
 * 2016/10/11
 * <p/>
 * 验证id_token
 *
 * @author Shengzhao Li
 */
public class IdTokenVerifier {

    private static final Logger LOG = LoggerFactory.getLogger(IdTokenVerifier.class);

    protected final String idToken;

    protected PublicKey publicKey;

    /**
     * Construct by idToken, publicKey
     *
     * @param idToken   idToken
     * @param publicKey publicKey
     */
    public IdTokenVerifier(String idToken, PublicKey publicKey) {
        this.idToken = idToken;
        this.publicKey = publicKey;
    }


    /**
     * 验证 id_token
     *
     * @return VerifyIdTokenResult
     * @throws java.lang.NullPointerException if the idToken is null or asHost is null
     */
    public VerifyIdTokenResult verify() {

        if (this.idToken == null) {
            throw new NullPointerException("idToken is null");
        }
        if (this.publicKey == null) {
            throw new NullPointerException("publicKey is null");
        }
        LOG.debug(String.format("Start verify idToken: %s, publicKey: %s", this.idToken, this.publicKey));

        /*
        * 1. 检查idToken 值 是否正确
        * */
        final JsonWebSignature jws = new JsonWebSignature();
        try {
            jws.setCompactSerialization(this.idToken);
        } catch (JoseException e) {
            LOG.warn("JWS set idToken exception", e);
            return handleError(INVALID_ID_TOKEN, "JWS set idToken exception: " + e.getMessage());
        }

        /*
        * 2. 通过 keyId, 获取 public key
        * */
        final String keyId = getKeyId(jws);
        LOG.debug(String.format("Get keyId: %s from the idToken", keyId));


        /*
        * 3. JWS 设置 public key
        * */
        jws.setKey(this.publicKey);

        /*
        * 4. 验证签名是否正确
        * */
        try {
            final boolean verifySignature = getVerifySignature(jws);
            if (!verifySignature) {
                LOG.debug("Verify idToken signature failed");
                return handleError(VERIFY_SIGNATURE_FAILED, "Verify signature failed");
            }
        } catch (JoseException e) {
            LOG.warn("JWS verify signature exception", e);
            return handleError(VERIFY_SIGNATURE_EXCEPTION, "JWS verify signature exception: " + e.getMessage());
        }

        /*
        * 5. 获取payload
        * */
        String payload;
        try {
            payload = getPayload(jws);
        } catch (JoseException e) {
            LOG.warn("JWS get payload exception", e);
            return handleError(GET_PAYLOAD_EXCEPTION, "JWS get payload exception: " + e.getMessage());
        }

        /*
        * 6. 转化payload为 JwtClaims
        * */

        JwtClaims jwtClaims;
        try {
            jwtClaims = getJwtClaims(payload);
        } catch (InvalidJwtException e) {
            LOG.warn("Parse payload to JwtClaims exception", e);
            return handleError(PARSE_PAYLOAD_EXCEPTION, "Parse payload to JwtClaims exception: " + e.getMessage());
        }

        /*
        * 7. 验证 idToken exp (过期时间)
        * */
        try {
            boolean expired = checkingIdTokenExpired(jwtClaims);
            if (expired) {
                LOG.debug("Expired idToken");
                return handleError(ID_TOKEN_EXPIRED, "idToken expired");
            }
        } catch (MalformedClaimException e) {
            LOG.warn("Get ExpirationTime from JwtClaims exception", e);
            return handleError(GET_EXPIRATION_TIME_EXCEPTION, "Get ExpirationTime from JwtClaims exception: " + e.getMessage());
        }

        /*
        * 8, 验证完成, 返回结果
        * */
        return verifySuccessful(jwtClaims, keyId);
    }


    /**
     * 验证 idToken 成功后的返回操作
     *
     * @param jwtClaims JwtClaims
     * @param keyId     keyId
     * @return VerifyIdTokenResult
     */
    protected VerifyIdTokenResult verifySuccessful(JwtClaims jwtClaims, String keyId) {
        final Map<String, Object> claimsMap = jwtClaims.getClaimsMap();
        return new VerifyIdTokenResult(claimsMap);
    }


    /*
    * 判断 idToken 是否过期
    * 在当前时间之前都是过期的(包括当前时间)
    * */
    protected boolean checkingIdTokenExpired(JwtClaims jwtClaims) throws MalformedClaimException {
        final NumericDate expirationTime = jwtClaims.getExpirationTime();
        if (expirationTime == null) {
            LOG.debug("Not found expirationTime from JwtClaims: {}, ignore checking id_token expired", jwtClaims);
            return false;
        }
        return !expirationTime.isAfter(NumericDate.now());
    }


    /*
    * 从JWS  验证签名
    * */
    protected boolean getVerifySignature(JsonWebSignature jws) throws JoseException {
        return jws.verifySignature();
    }


    /*
    * 从 JWS中获取 keyId
    * */
    protected String getKeyId(JsonWebSignature jws) {
        return jws.getKeyIdHeaderValue();
    }


    /*
    * 处理 异常情况时的 返回值
    * */
    protected VerifyIdTokenResult handleError(int statusCode, String error) {
        return new VerifyIdTokenResult(statusCode, error);
    }

    /*
    * 从JWS中获取 payload
    * */
    protected String getPayload(JsonWebSignature jws) throws JoseException {
        return jws.getPayload();
    }

    /*
    * payload 转化为 JwtClaims
    * */
    protected JwtClaims getJwtClaims(String payload) throws InvalidJwtException {
        return JwtClaims.parse(payload);
    }


}
