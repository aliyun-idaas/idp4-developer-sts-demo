package com.idsmanager.oidc;

import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.lang.JoseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * 2017/1/10
 * <p/>
 * 生成 RSA keyPair
 *
 * @author Shengzhao Li
 */
public class OIDCRsaKeyPairGenerator {

    private static final Logger LOG = LoggerFactory.getLogger(OIDCRsaKeyPairGenerator.class);


    /**
     * 用于加密的默认位数 2048
     */
    public static final int DEFAULT_BITS = 2048;


    /**
     * 默认生成 keypair 时使用的算法
     */
    public static final String DEFAULT_ALGORITHM = AlgorithmIdentifiers.RSA_USING_SHA256;


    protected int bits = DEFAULT_BITS;

    protected String algorithm = DEFAULT_ALGORITHM;


    protected String keyId;


    public OIDCRsaKeyPairGenerator() {
    }

    public OIDCRsaKeyPairGenerator(String keyId) {
        this.keyId = keyId;
    }


    /*
    * 设置 加密的位数
    *
    * */
    public OIDCRsaKeyPairGenerator bits(int bits) {
        this.bits = bits;
        return this;
    }

    /**
     * 设置加密的算法
     *
     * @param algorithm {@link org.jose4j.jws.AlgorithmIdentifiers#ECDSA_USING_P256_CURVE_AND_SHA256},
     *                  {@link org.jose4j.jws.AlgorithmIdentifiers#ECDSA_USING_P384_CURVE_AND_SHA384},
     *                  {@link org.jose4j.jws.AlgorithmIdentifiers#ECDSA_USING_P521_CURVE_AND_SHA512} and so on
     */
    public OIDCRsaKeyPairGenerator algorithm(String algorithm) {
        this.algorithm = algorithm;
        return this;
    }


    /**
     * 生成 keypair
     *
     * @return OIDCKeyPair
     * @throws org.jose4j.lang.JoseException
     */
    public OIDCKeyPair generate() throws JoseException {

        checkingKeyId();
        JsonWebKey jwk = getJsonWebKey();

        final String publicKeyJson = jwk.toJson(JsonWebKey.OutputControlLevel.PUBLIC_ONLY);
        final String privateKeyJson = jwk.toJson(JsonWebKey.OutputControlLevel.INCLUDE_PRIVATE);

        final OIDCKeyPair keyPair = new OIDCKeyPair(publicKeyJson, privateKeyJson);
        keyPair.keyId(this.keyId);
        return keyPair;
    }


    /*
    * 检查 keyId, 若为空则生成一个随机的
    * */
    protected void checkingKeyId() {
        if (this.keyId == null) {
            this.keyId = UUID.randomUUID().toString();
            LOG.debug("Use random keyId: {}", this.keyId);
        }
    }


    /*
     * 获取 JsonWebKey
     */
    protected JsonWebKey getJsonWebKey() throws JoseException {
        JsonWebKey jwk = RsaJwkGenerator.generateJwk(this.bits);
        jwk.setKeyId(this.keyId);
        jwk.setAlgorithm(this.algorithm);
        LOG.debug("Generate JsonWebKey: {}, keyId: {}, algorithm: {}", jwk, this.keyId, this.algorithm);
        return jwk;
    }


}
