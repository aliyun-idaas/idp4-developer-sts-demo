package com.idsmanager.oidc.p12;


import org.jose4j.base64url.internal.apache.commons.codec.binary.Base64;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.NumericDate;
import org.jose4j.lang.JoseException;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


/**
 * 2016/11/3
 * <p/>
 * <p/>
 * P12 生成 id_token
 *
 * @author Shengzhao Li
 */
public class P12IdTokenGenerator {

    /**
     * 默认的id_token有效时间: 10分钟
     */
    public static final long DEFAULT_TOKEN_SECONDS = 600L;


    /**
     * 默认的 Audience
     */
    public static final String DEFAULT_AUDIENCE = "IDS_AUDIENCE";

    /**
     * 默认的 Subject
     */
    public static final String DEFAULT_SUBJECT = "IDS_Subject";


    private String privateKeyAsString;
    private PrivateKey privateKey;

    private Map<String, Object> map = new HashMap<String, Object>();

    public P12IdTokenGenerator(String privateKeyAsString, Map<String, Object> map) {
        this.privateKeyAsString = privateKeyAsString;
        this.map = map;
    }


    public P12IdTokenGenerator(PrivateKey privateKey, Map<String, Object> map) {
        this.privateKey = privateKey;
        this.map = map;
    }

    /*
     * 生成 id_token
     */
    public String generate() throws Exception {

        JwtClaims claims = getJwtClaims();
        JsonWebSignature jws = getJsonWebSignature(claims);

        return getIdToken(jws);
    }


    /**
     * 从 JsonWebSignature 从获取  id_token
     *
     * @param jws JsonWebSignature
     * @return idToken
     * @throws org.jose4j.lang.JoseException
     */
    protected String getIdToken(JsonWebSignature jws) throws JoseException {
        return jws.getCompactSerialization();
    }

    /**
     * 获取 JsonWebSignature
     *
     * @param claims JwtClaims
     * @return JsonWebSignature
     * @throws org.jose4j.lang.JoseException
     */
    protected JsonWebSignature getJsonWebSignature(JwtClaims claims) throws JoseException {
        JsonWebSignature jws = createJsonWebSignature();
        setJsonWebSignaturePayload(claims, jws);

        setJsonWebSignaturePrivateKey(jws);
//        jws.setKeyIdHeaderValue(jwk.getKeyId());
        return jws;
    }


    /**
     * 创建 JsonWebSignature
     *
     * @return JsonWebSignature
     */
    protected JsonWebSignature createJsonWebSignature() {
        JsonWebSignature jws = new JsonWebSignature();
        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
        return jws;
    }

    /**
     * 设置 JsonWebSignature 中的 Payload
     *
     * @param claims JwtClaims
     * @param jws    JsonWebSignature
     */
    protected void setJsonWebSignaturePayload(JwtClaims claims, JsonWebSignature jws) {
        jws.setPayload(claims.toJson());
    }


    /**
     * 设置 JsonWebSignature 中的 privateKey
     *
     * @param jws JsonWebSignature
     * @throws org.jose4j.lang.JoseException JoseException
     */
    protected void setJsonWebSignaturePrivateKey(JsonWebSignature jws) throws JoseException {
        if (this.privateKey != null) {
            jws.setKey(privateKey);
        } else {
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(this.privateKeyAsString));
            try {
                final KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                final PrivateKey privateKey1 = keyFactory.generatePrivate(keySpec);
                jws.setKey(privateKey1);
            } catch (Exception e) {
                throw new JoseException("P12 get privateKey failed", e);
            }

        }
    }


    /**
     * 获取 JwtClaims
     *
     * @return JwtClaims
     */
    protected JwtClaims getJwtClaims() {

        JwtClaims claims = new JwtClaims();
        setIdTokenExpirationTime(claims);
        setAudience(claims);
        setSubject(claims);

        claims.setGeneratedJwtId();
        claims.setIssuedAtToNow();
        //past 1 minute
        claims.setNotBeforeMinutesInThePast(1);

        setMoreClaims(claims);

        setClaimsMap(claims);

        return claims;
    }

    /**
     * 设置 用户传入的 claimMap
     *
     * @param claims JwtClaims
     */
    protected void setClaimsMap(JwtClaims claims) {
        if (this.map != null) {
            final Set<String> set = this.map.keySet();
            for (String key : set) {
                claims.setClaim(key, this.map.get(key));
            }
        }
    }


    /**
     * 扩展, 用于子类 设置 更多  JwtClaims 中的属性
     *
     * @param claims JwtClaims
     */
    protected void setMoreClaims(JwtClaims claims) {
    }


    /**
     * 设置 JwtClaims 中的  Subject
     *
     * @param claims JwtClaims
     */
    protected void setSubject(JwtClaims claims) {
        claims.setSubject(getSubject());
    }


    /**
     * 获取 JwtClaims中的 Subject
     *
     * @return Audience
     */
    protected String getSubject() {
        return DEFAULT_SUBJECT;
    }


    /**
     * 设置 JwtClaims 中的  Audience
     *
     * @param claims JwtClaims
     */
    protected void setAudience(JwtClaims claims) {
        claims.setAudience(getAudience());
    }


    /**
     * 获取 JwtClaims中的 Audience
     *
     * @return Audience
     */
    protected String getAudience() {
        return DEFAULT_AUDIENCE;
    }


    /**
     * 设置　id_token 过期时间
     *
     * @param claims JwtClaims
     */
    protected void setIdTokenExpirationTime(JwtClaims claims) {
        // expire time
        NumericDate date = NumericDate.now();
        date.addSeconds(getIdTokenSeconds());
        claims.setExpirationTime(date);
    }


    /**
     * id_token的 有效时长, 单位:秒
     *
     * @return Seconds of id_token
     */
    protected long getIdTokenSeconds() {
        return DEFAULT_TOKEN_SECONDS;
    }


}
