package com.idsmanager.oidc.rs.result;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 2016/9/26
 * <p/>
 * API 返回结果抽象类
 *
 * @author DSF
 */
public abstract class APIResult implements Serializable {


    private static final long serialVersionUID = -2867721822060092251L;

    //成功的 状态码: 0
    public static final int SUCCESS_STATUS_CODE = 0;

    /**
     * 响应的状态码
     */
    protected int statusCode;

    /**
     * 异常信息
     */
    protected List<String> errors = new ArrayList<String>();


    public APIResult() {
    }

    public APIResult(int statusCode, String error) {
        this.statusCode = statusCode;
        this.errors.add(error);
    }


    /*
    * 判断请求返回 的API 结果是否成功
    * */
    public boolean getSuccessful() {
        return this.statusCode == SUCCESS_STATUS_CODE;
    }


    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
}
