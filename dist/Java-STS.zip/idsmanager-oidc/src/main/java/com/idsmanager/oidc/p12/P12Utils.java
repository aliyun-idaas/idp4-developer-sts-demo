package com.idsmanager.oidc.p12;


import com.idsmanager.oidc.Constants;
import org.apache.commons.io.IOUtils;
import org.jose4j.base64url.internal.apache.commons.codec.binary.Base64;


import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

/**
 * 2016/11/22
 * <p/>
 * <p/>
 * P12 文件相关操作
 * 使用RSA 算法
 *
 * @author Shengzhao Li
 */
public abstract class P12Utils {

    public static final String PKC = "PKCS12";

    public static final String BEGIN_CERTIFICATE = "-----BEGIN CERTIFICATE-----";
    public static final String END_CERTIFICATE = "-----END CERTIFICATE-----";


    private P12Utils() {
    }


    /*
     * 从P12文件中获取 所有公钥
     *
     */
    public static List<PublicKey> getPublicKeysFromP12(InputStream p12InputStream, String password) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
        if (p12InputStream == null || password == null) {
            throw new NullPointerException("p12InputStream or password is null");
        }
        KeyStore keyStore = getKeyStoreFromP12(p12InputStream, password);

        List<PublicKey> publicKeys = new ArrayList<>();
        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final Certificate certificate = keyStore.getCertificate(alias);
            publicKeys.add(certificate.getPublicKey());
        }

        return Collections.unmodifiableList(publicKeys);
    }


    /*
     * 从P12文件中获取 所有公钥, 字符格式
     *
     */
    public static List<String> getPublicKeysTextFromP12(InputStream p12InputStream, String password) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
        if (p12InputStream == null || password == null) {
            throw new NullPointerException("p12InputStream or password is null");
        }
        KeyStore keyStore = getKeyStoreFromP12(p12InputStream, password);

        List<String> publicKeys = new ArrayList<>();
        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final Certificate certificate = keyStore.getCertificate(alias);
            byte[] certData = certificate.getEncoded();

            final String publicKey = new String(Base64.encodeBase64Chunked(certData), Constants.DEFAULT_CHARSET);
            publicKeys.add(publicKey);
        }

        return Collections.unmodifiableList(publicKeys);
    }


    /*
    * 将一个P12 文件的 private key 字符串 转化为 PrivateKey 对象
    *
    * */
    public static PrivateKey getPrivateKeyByText(String privateKeyAsText) throws NoSuchAlgorithmException, InvalidKeySpecException {
        if (privateKeyAsText == null) {
            throw new NullPointerException("privateKeyAsText is null");
        }
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKeyAsText));
        final KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(keySpec);
    }


    /*
     * 从P12文件中获取 所有私钥
     *
     */
    public static List<PrivateKey> getPrivateKeysFromP12(InputStream p12InputStream, String password)
            throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException, UnrecoverableKeyException {
        if (p12InputStream == null || password == null) {
            throw new NullPointerException("p12InputStream or password is null");
        }
        KeyStore keyStore = getKeyStoreFromP12(p12InputStream, password);
        char[] pwd = password.toCharArray();

        List<PrivateKey> list = new ArrayList<>();
        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final Key key = keyStore.getKey(alias, pwd);
            if (key instanceof PrivateKey) {
                final PrivateKey privateKey = (PrivateKey) key;
                list.add(privateKey);
            }
        }

        return Collections.unmodifiableList(list);
    }


    /*
     * 从P12文件中获取 所有alias
     *
     */
    public static List<String> getAliasesFromP12(InputStream p12InputStream, String password) throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
        if (p12InputStream == null || password == null) {
            throw new NullPointerException("p12InputStream or password is null");
        }
        KeyStore keyStore = getKeyStoreFromP12(p12InputStream, password);

        List<String> list = new ArrayList<>();
        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            list.add(alias);
        }

        return Collections.unmodifiableList(list);
    }


    /*
    * 从P12文件中获取 KeyStore
    * */
    public static KeyStore getKeyStoreFromP12(InputStream p12InputStream, String password) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {
        if (p12InputStream == null || password == null) {
            throw new NullPointerException("p12InputStream or password is null");
        }
        KeyStore keyStore = KeyStore.getInstance(PKC);
        char[] pwd = password.toCharArray();
        keyStore.load(p12InputStream, pwd);
        return keyStore;
    }


    /*
    * P12 文件 转化为 字符串
    * */
    public static String p12ToString(InputStream p12InputStream) throws IOException {
        if (p12InputStream == null) {
            throw new NullPointerException("p12InputStream is null");
        }

        final byte[] bytes = IOUtils.toByteArray(p12InputStream);
        final byte[] encode = Base64.encodeBase64(bytes);
        return new String(encode);
    }


    /*
    * PrivateKey 转化为 字符串
    * */
    public static String privateKeyToString(PrivateKey privateKey) throws IOException {
        if (privateKey == null) {
            throw new NullPointerException("privateKey is null");
        }

        byte[] keyData = privateKey.getEncoded();
        return Base64.encodeBase64String(keyData);
    }


    /*
    * PublicKey 转化为 字符串
    * */
    public static String publicKeyToString(PublicKey publicKey) throws IOException {
        if (publicKey == null) {
            throw new NullPointerException("publicKey is null");
        }

        byte[] keyData = publicKey.getEncoded();
        return Base64.encodeBase64String(keyData);
    }


}
