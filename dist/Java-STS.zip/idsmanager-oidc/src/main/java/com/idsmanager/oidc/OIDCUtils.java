package com.idsmanager.oidc;

import org.jose4j.json.JsonUtil;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jwk.PublicJsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.keys.AesKey;
import org.jose4j.lang.JoseException;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;
import java.util.Map;

/**
 * 2017/1/10
 * <p/>
 * OIDC 操作相关工具类
 * <p/>
 * 可逆的加密/解密
 *
 * @author Shengzhao Li
 */
public abstract class OIDCUtils {


    /**
     * 默认加密使用的AES key, length: 32
     */
    public static final String AES_KEY = "Jq2mwkO7BxeAV67p5tPrCOSwyfpwVQ7I";


    private OIDCUtils() {
    }


    /**
     * JSON public key to PublicKey
     *
     * @param publicKeyJson PublicKey as Json
     * @return PublicKey
     * @throws JoseException
     */
    public static PublicKey jsonToPublicKey(String publicKeyJson) throws JoseException {
        if (publicKeyJson == null) {
            return null;
        }
        final PublicJsonWebKey jwk = PublicJsonWebKey.Factory.newPublicJwk(publicKeyJson);
        return jwk.getPublicKey();
    }

    /**
     * JSON private key to PrivateKey
     *
     * @param privateKeyJson PrivateKey as Json
     * @return PrivateKey
     * @throws JoseException
     */
    public static PrivateKey jsonToPrivateKey(String privateKeyJson) throws JoseException {
        if (privateKeyJson == null) {
            return null;
        }
        final Map<String, Object> params = JsonUtil.parseJson(privateKeyJson);
        return new RsaJsonWebKey(params).getPrivateKey();
    }


    /**
     * AES 加密, 256位
     *
     * @param data Need encrypt data
     * @return id_token
     */
    public static String aesEncrypt(String data) {
        return aesEncrypt(data, AES_KEY.getBytes());
    }

    /**
     * AES 加密, 256位
     *
     * @param data   Need encrypt data
     * @param aesKey Encrypt key, length 32
     * @return id_token
     */
    public static String aesEncrypt(String data, byte[] aesKey) {
        return aesEncrypt(data, aesKey, false);
    }

    /**
     * AES 加密, 256位
     * 输出base64格式
     *
     * @param data   Need encrypt data
     * @param aesKey Encrypt key, length 32
     * @param base64 Use base64 or not
     * @return id_token base64
     */
    public static String aesEncrypt(String data, byte[] aesKey, boolean base64) {
        if (data == null || aesKey == null) {
            return null;
        }
        JsonWebEncryption jwe = new JsonWebEncryption();
        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.A256KW);
        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_256_CBC_HMAC_SHA_512);

        final AesKey key = new AesKey(aesKey);
        jwe.setKey(key);
        jwe.setPayload(data);

        try {
            final String serialization = jwe.getCompactSerialization();
            return base64 ? Base64.getEncoder().encodeToString(serialization.getBytes(Constants.DEFAULT_CHARSET)) : serialization;
        } catch (JoseException e) {
            throw new IllegalStateException("aesEncrypt error", e);
        }
    }


    /**
     * AES解密, 256位
     *
     * @param idToken idToken
     * @param aesKey  Aes key, length 32
     * @return data
     */
    public static String aesDecrypt(String idToken, byte[] aesKey) {
        return aesDecrypt(idToken, aesKey, false);
    }

    /**
     * AES解密, 256位,
     * base64 格式数据
     *
     * @param idToken idToken base64
     * @param aesKey  Aes key, length 32
     * @return data
     */
    public static String aesDecrypt(String idToken, byte[] aesKey, boolean base64) {
        if (idToken == null || aesKey == null) {
            return null;
        }
        JsonWebEncryption jwe = new JsonWebEncryption();
        final AesKey key = new AesKey(aesKey);
        jwe.setKey(key);
        try {
            if (base64) {
                final byte[] decode = Base64.getDecoder().decode(idToken);
                jwe.setCompactSerialization(new String(decode, Constants.DEFAULT_CHARSET));
            } else {
                jwe.setCompactSerialization(idToken);
            }
            return jwe.getPayload();
        } catch (JoseException e) {
            throw new IllegalStateException("aesDecrypt error", e);
        }
    }


    /**
     * AES解密, 256位
     *
     * @param idToken idToken
     * @return data
     */
    public static String aesDecrypt(String idToken) {
        return aesDecrypt(idToken, AES_KEY.getBytes());
    }


}
