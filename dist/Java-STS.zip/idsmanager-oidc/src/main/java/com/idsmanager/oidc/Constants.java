package com.idsmanager.oidc;

import java.nio.charset.Charset;

/**
 * 2016/5/16
 *
 * @author Shengzhao Li
 */
public interface Constants {


    static final String ENCODING = "UTF-8";

    static final Charset DEFAULT_CHARSET = Charset.forName(ENCODING);



    /**
     * AS未找到对应的OIDC KeyPair
     */
    static final int NOT_FOUND_KEY_PAIR = 233;


    /**
     * JWS设置 id_token 值 失败, 请检查id_token值
     */
    static final int INVALID_ID_TOKEN = 234;


    /**
     * JWS设置 Public key 值 异常
     */
    static final int INVALID_PUBLIC_KEY = 235;


    /**
     * JWS 验证 签名异常
     */
    static final int VERIFY_SIGNATURE_EXCEPTION = 236;


    /**
     * JWS 验证 签名失败
     */
    static final int VERIFY_SIGNATURE_FAILED = 237;


    /**
     * JWS 获取 payload 异常
     */
    static final int GET_PAYLOAD_EXCEPTION = 238;


    /**
     * 解析 payload 为 JwtClaims 异常
     */
    static final int PARSE_PAYLOAD_EXCEPTION = 239;


    /**
     * 从JwtClaims 中获取 ExpirationTime(过期时间) 异常
     */
    static final int GET_EXPIRATION_TIME_EXCEPTION = 240;


    /**
     * id_token 已过期
     */
    static final int ID_TOKEN_EXPIRED = 241;




}
