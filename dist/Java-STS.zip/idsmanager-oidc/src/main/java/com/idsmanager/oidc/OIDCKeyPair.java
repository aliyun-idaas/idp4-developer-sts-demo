package com.idsmanager.oidc;

import org.jose4j.lang.JoseException;

import java.io.Serializable;
import java.security.PrivateKey;
import java.security.PublicKey;

/**
 * 2017/1/10
 *
 * @author Shengzhao Li
 */
public class OIDCKeyPair implements Serializable {

    private static final long serialVersionUID = 1827519322504437725L;

    private String keyId;
    //公钥
    private String publicKeyJson;
    //私钥
    private String privateKeyJson;


    public OIDCKeyPair() {
    }


    public OIDCKeyPair(String publicKeyJson, String privateKeyJson) {
        this.publicKeyJson = publicKeyJson;
        this.privateKeyJson = privateKeyJson;
    }


    /*
    * 获取 private key
    * */
    public PrivateKey privateKey() throws JoseException {
        return OIDCUtils.jsonToPrivateKey(this.privateKeyJson);
    }

    /*
    * 获取 public key
    * */
    public PublicKey publicKey() throws JoseException {
        return OIDCUtils.jsonToPublicKey(this.publicKeyJson);
    }


    public String keyId() {
        return keyId;
    }

    public OIDCKeyPair keyId(String keyId) {
        this.keyId = keyId;
        return this;
    }

    public String publicKeyJson() {
        return publicKeyJson;
    }

    public OIDCKeyPair publicKeyJson(String publicKeyJson) {
        this.publicKeyJson = publicKeyJson;
        return this;
    }

    public String privateKeyJson() {
        return privateKeyJson;
    }

    public OIDCKeyPair privateKeyJson(String privateKeyJson) {
        this.privateKeyJson = privateKeyJson;
        return this;
    }


    @Override
    public String toString() {
        return "{" +
                "keyId='" + keyId + '\'' +
                ", publicKeyJson='" + publicKeyJson + '\'' +
                ", privateKeyJson='" + privateKeyJson + '\'' +
                '}';
    }
}
