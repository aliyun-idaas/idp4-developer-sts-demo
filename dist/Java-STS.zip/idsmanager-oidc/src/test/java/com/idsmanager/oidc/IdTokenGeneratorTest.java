package com.idsmanager.oidc;

import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.JwtClaims;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.testng.Assert.assertNotNull;

/**
 * @author Shengzhao Li
 */
public class IdTokenGeneratorTest {


    @Test
    public void generate() throws Exception {
        String keyId = String.valueOf(UUID.randomUUID().getLeastSignificantBits());
        RsaJsonWebKey jwk = RsaJwkGenerator.generateJwk(2048);

        jwk.setKeyId(keyId);
        jwk.setAlgorithm(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);

        String privateKey = jwk.toJson(JsonWebKey.OutputControlLevel.INCLUDE_PRIVATE);
//        String publicKey = jwk.toJson(JsonWebKey.OutputControlLevel.PUBLIC_ONLY);


//        System.out.println("keyId: \n" + keyId);
//        System.out.println("privateKey: \n" + privateKey);
//        System.out.println("publicKey: \n" + publicKey);
        //7773055796742473915

        //{"exp":1479439571,"aud":"IDS_AUDIENCE","sub":"IDS_Subject","jti":"PkkuWIIRkKKtSqoDy9YJ1g","iat":1479438971,"nbf":1479438911,"deviceId":"15819b4824134c7db3c6ce608e212cd3sEMlVNL7","timestamp":1479438923062}


        Map<String, Object> map = new HashMap<>();
        map.put("deviceId", UUID.randomUUID().toString());
        map.put("timestamp", System.currentTimeMillis());

        //case 1
        IdTokenGenerator idTokenGenerator = new IdTokenGenerator(privateKey, map);
        final String idToken = idTokenGenerator.generate();

        assertNotNull(idToken);
//        System.out.println(idToken);

        //case 2
        IdTokenGenerator idTokenGenerator2 = new IdTokenGenerator(jwk.getRsaPrivateKey(), map);
        final String idToken2 = idTokenGenerator2.generate();
        assertNotNull(idToken2);

        //case 3
        JwtClaims claims = new JwtClaims();
        claims.setGeneratedJwtId();
        claims.setAudience("Audience");

        IdTokenGenerator idTokenGenerator3 = new IdTokenGenerator(jwk.getRsaPrivateKey(), claims);
        final String idToken3 = idTokenGenerator3.generate();
        assertNotNull(idToken3);

        //case 4
        IdTokenGenerator idTokenGenerator4 = new IdTokenGenerator(privateKey, claims);
        final String idToken4 = idTokenGenerator4.generate();
        assertNotNull(idToken4);

        //case 5
        IdTokenGenerator idTokenGenerator5 = new IdTokenGenerator(privateKey, claims).algorithm(AlgorithmIdentifiers.RSA_USING_SHA512);
        final String idToken5 = idTokenGenerator5.generate();
        assertNotNull(idToken5);


    }


}