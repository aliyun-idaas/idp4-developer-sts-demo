package com.idsmanager.oidc;

import com.idsmanager.oidc.rs.IdTokenVerifier;
import com.idsmanager.oidc.rs.result.VerifyIdTokenResult;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.JwtClaims;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

/**
 * @author Shengzhao Li
 */
public class OIDCRsaKeyPairGeneratorTest {


    @Test
    public void generate() throws Exception {

        //case 1
        OIDCRsaKeyPairGenerator keyPairGenerator = new OIDCRsaKeyPairGenerator();
        final OIDCKeyPair keyPair = keyPairGenerator.generate();
        assertNotNull(keyPair);
        assertNotNull(keyPair.keyId());

        //case 2
        final String keyId = "abc";
        OIDCRsaKeyPairGenerator keyPairGenerator2 = new OIDCRsaKeyPairGenerator(keyId).bits(1024);
        final OIDCKeyPair keyPair2 = keyPairGenerator2.generate();
        assertNotNull(keyPair2);
        assertNotNull(keyPair2.publicKey());
        assertNotNull(keyPair2.privateKey());
        assertEquals(keyPair2.keyId(), keyId);


        //case 3
        OIDCRsaKeyPairGenerator keyPairGenerator3 = new OIDCRsaKeyPairGenerator()
                .algorithm(AlgorithmIdentifiers.ECDSA_USING_P521_CURVE_AND_SHA512);
        final OIDCKeyPair keyPair3 = keyPairGenerator3.generate();
        assertNotNull(keyPair3);
        assertNotNull(keyPair3.publicKey());
        assertNotNull(keyPair3.privateKey());


    }


    /**
     * 测试生成keyPair 与 id_token
     *
     * @throws Exception
     */
    @Test
    public void generateAndIdToken() throws Exception {


        OIDCRsaKeyPairGenerator keyPairGenerator3 = new OIDCRsaKeyPairGenerator()
                .algorithm(AlgorithmIdentifiers.RSA_USING_SHA512);
        final OIDCKeyPair keyPair3 = keyPairGenerator3.generate();
        assertNotNull(keyPair3);
        assertNotNull(keyPair3.publicKey());
        assertNotNull(keyPair3.privateKey());

        JwtClaims claims = new JwtClaims();
        claims.setGeneratedJwtId();
        claims.setAudience("Audience");

        IdTokenGenerator idTokenGenerator = new IdTokenGenerator(keyPair3.privateKey(), claims);
        final String idToken = idTokenGenerator.generate();
        assertNotNull(idToken);


        //Verify
        IdTokenVerifier verifier = new IdTokenVerifier(idToken, keyPair3.publicKey());
        final VerifyIdTokenResult result = verifier.verify();
        assertNotNull(result);
        assertTrue(result.getSuccessful());


    }


}