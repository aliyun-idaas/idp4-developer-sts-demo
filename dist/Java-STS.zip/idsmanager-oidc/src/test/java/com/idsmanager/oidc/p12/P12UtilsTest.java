package com.idsmanager.oidc.p12;

import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.List;

import static org.testng.Assert.*;

/**
 * @author Shengzhao Li
 */
public class P12UtilsTest {


    protected static String password = "mm23456";

    @Test
    public void getPublicKeysFromP12() throws Exception {

        InputStream is = getP12();

        final List<PublicKey> list = P12Utils.getPublicKeysFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);

        is.close();
    }


    @Test
    public void getPublicKeysTextFromP12() throws Exception {

        InputStream is = getP12();

        final List<String> list = P12Utils.getPublicKeysTextFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);
//        System.out.println(list);

        is.close();
    }


    @Test
    public void getPrivateKeysFromP12() throws Exception {

        InputStream is = getP12();

        final List<PrivateKey> list = P12Utils.getPrivateKeysFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);

        is.close();
    }


    @Test
    public void getAliasesFromP12() throws Exception {

        InputStream is = getP12();

        final List<String> list = P12Utils.getAliasesFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);
        System.out.println(list);

        is.close();
    }


    @Test
    public void p12ToString() throws Exception {

        InputStream is = getP12();

        final String text = P12Utils.p12ToString(is);
        assertNotNull(text);

        is.close();
    }


    @Test
    public void privateKeyToString() throws Exception {

        InputStream is = getP12();

        final List<PrivateKey> list = P12Utils.getPrivateKeysFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);

        final PrivateKey privateKey = list.get(0);
        final String text = P12Utils.privateKeyToString(privateKey);
        assertNotNull(text);
//        System.out.println(text);

        is.close();
    }


    @Test
    public void publicKeyToString() throws Exception {

        InputStream is = getP12();

        final List<PublicKey> list = P12Utils.getPublicKeysFromP12(is, password);
        assertNotNull(list);
        assertTrue(list.size() > 0);

        final PublicKey publicKey = list.get(0);
        final String text = P12Utils.publicKeyToString(publicKey);
        assertNotNull(text);
        System.out.println(text);

        is.close();
    }


    @Test
    public void getPrivateKeyByText() throws Exception {

        final InputStream p12 = getP12();

        final List<PrivateKey> keys = P12Utils.getPrivateKeysFromP12(p12, password);
        for (PrivateKey key : keys) {
            String pk = P12Utils.privateKeyToString(key);
            final PrivateKey privateKey = P12Utils.getPrivateKeyByText(pk);
            assertNotNull(privateKey);
            assertEquals(privateKey, key);
        }

        p12.close();


    }


    private InputStream getP12() throws IOException {
        return this.getClass().getClassLoader().getResourceAsStream("mm23456.p12");
    }


}