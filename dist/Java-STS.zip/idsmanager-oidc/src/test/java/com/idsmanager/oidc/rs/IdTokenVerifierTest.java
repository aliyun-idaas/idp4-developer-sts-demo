package com.idsmanager.oidc.rs;

import com.idsmanager.oidc.Constants;
import com.idsmanager.oidc.IdTokenGenerator;
import com.idsmanager.oidc.rs.result.VerifyIdTokenResult;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.NumericDate;
import org.testng.annotations.Test;

import java.security.PublicKey;
import java.util.Map;
import java.util.UUID;

import static org.testng.Assert.*;

/**
 * @author Shengzhao Li
 */
public class IdTokenVerifierTest {


    /*
    * 测试 JwtClaims 的解析
    * */
    @Test
    public void testJwtClaims() throws Exception {

        String payload = "{\"exp\":1476178396,\"jti\":\"0kAZcRmYTJxXpjB2m2qfjQ\",\"iat\":1476177796,\"nbf\":1476177736,\"sub\":\"3134565229594035029\"}";
        final JwtClaims claims = JwtClaims.parse(payload);

        assertNotNull(claims);
        final NumericDate expirationTime = claims.getExpirationTime();
        assertNotNull(expirationTime);

    }

    /*
    * 测试 参数 为 NULL的情况
    * */
    @Test(expectedExceptions = NullPointerException.class)
    public void testNull() {

        String idToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjY2NTI3OTEzMjQ3MjkwMzU4OTcifQ.eyJleHAiOjE0NzYxNzgzOT...";

        //Test case 1:  null idToken, not null asHost
        IdTokenVerifier idTokenVerifier = new IdTokenVerifier(null, null);
        idTokenVerifier.verify();

        //Test case 2:  null asHost, not null idToken
        final IdTokenVerifier idTokenVerifier1 = new IdTokenVerifier(idToken, null);
        idTokenVerifier1.verify();

        //Test case 3: null idToken, null asHost
        IdTokenVerifier idTokenVerifier2 = new IdTokenVerifier(null, null);
        idTokenVerifier2.verify();
    }


    /*
    *
    *  测试 idToken 不正确的情况
    * */
    @Test
    public void invalidIdToken() throws Exception {

        String keyId = String.valueOf(UUID.randomUUID().getLeastSignificantBits());
        RsaJsonWebKey jwk = RsaJwkGenerator.generateJwk(2048);

        jwk.setKeyId(keyId);
        jwk.setAlgorithm(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
        final PublicKey publicKey = jwk.getPublicKey();


        //Test case 1:  idToken is string
        String idToken = "8sfdafswefdsddddds";
        IdTokenVerifier idTokenVerifier = new IdTokenVerifier(idToken, publicKey);
        final VerifyIdTokenResult result = idTokenVerifier.verify();

        assertNotNull(result);
        assertTrue(result.getStatusCode() == Constants.INVALID_ID_TOKEN);

        //Test case 2: idToken is empty string
        idToken = "";
        IdTokenVerifier idTokenVerifier2 = new IdTokenVerifier(idToken, publicKey);
        final VerifyIdTokenResult result2 = idTokenVerifier2.verify();

        assertNotNull(result2);
        assertTrue(result2.getStatusCode() == Constants.INVALID_ID_TOKEN);

        //Test case 3: idToken is integer
        idToken = "887455656552";
        IdTokenVerifier idTokenVerifier3 = new IdTokenVerifier(idToken, publicKey);
        final VerifyIdTokenResult result3 = idTokenVerifier3.verify();

        assertNotNull(result3);
        assertTrue(result3.getStatusCode() == Constants.INVALID_ID_TOKEN);


    }


    /*
*
* 测试 verify  正常
* */
    @Test(enabled = true)
    public void getVerifyOK() throws Exception {


        String keyId = String.valueOf(UUID.randomUUID().getLeastSignificantBits());
        RsaJsonWebKey jwk = RsaJwkGenerator.generateJwk(2048);

        jwk.setKeyId(keyId);
        jwk.setAlgorithm(AlgorithmIdentifiers.ECDSA_USING_P256_CURVE_AND_SHA256);
        final PublicKey publicKey = jwk.getPublicKey();

        //id_token
        JwtClaims claims = new JwtClaims();
        claims.setGeneratedJwtId();
        claims.setAudience("Audience");
        IdTokenGenerator idTokenGenerator = new IdTokenGenerator(jwk.getPrivateKey(), claims).keyId(keyId);
        String idToken = idTokenGenerator.generate();

        IdTokenVerifier idTokenVerifier = new IdTokenVerifier(idToken, publicKey);
        final VerifyIdTokenResult result = idTokenVerifier.verify();

        assertNotNull(result);
        assertTrue(result.getSuccessful());
        assertEquals(result.getStatusCode(), 0);

        final Map<String, Object> claimsMap = result.getClaimsMap();
        assertTrue(claimsMap.size() > 0);
        System.out.println(claimsMap);

    }


    /**
     * 测试 verify  正常
     * RS256
     */
    @Test(enabled = true)
    public void getVerifyRS256OK() throws Exception {


        String keyId = String.valueOf(UUID.randomUUID().getLeastSignificantBits());
        RsaJsonWebKey jwk = RsaJwkGenerator.generateJwk(2048);

        jwk.setKeyId(keyId);
        jwk.setAlgorithm(AlgorithmIdentifiers.RSA_USING_SHA256);
        final PublicKey publicKey = jwk.getPublicKey();

        //id_token
        JwtClaims claims = new JwtClaims();
        claims.setGeneratedJwtId();
        claims.setAudience("Audience RSA");
        IdTokenGenerator idTokenGenerator = new IdTokenGenerator(jwk.getPrivateKey(), claims).keyId(keyId);
        String idToken = idTokenGenerator.generate();

        IdTokenVerifier idTokenVerifier = new IdTokenVerifier(idToken, publicKey);
        final VerifyIdTokenResult result = idTokenVerifier.verify();

        assertNotNull(result);
        assertTrue(result.getSuccessful());
        assertEquals(result.getStatusCode(), 0);

        final Map<String, Object> claimsMap = result.getClaimsMap();
        assertTrue(claimsMap.size() > 0);
        System.out.println(claimsMap);

    }


}