package com.idsmanager.oidc;

import org.jose4j.lang.JoseException;
import org.testng.annotations.Test;

import java.security.PrivateKey;
import java.security.PublicKey;

import static org.testng.Assert.*;

/**
 * @author Shengzhao Li
 */
public class OIDCUtilsTest {


    @Test
    public void jsonToPublicKey() throws Exception {
        final OIDCKeyPair keyPair = getOidcKeyPair();

        final PublicKey publicKey = OIDCUtils.jsonToPublicKey(keyPair.publicKeyJson());
        assertNotNull(publicKey);


//        final PublicKey publicKey1 = OIDCUtils.jsonToPublicKey(null);
//        assertTrue(publicKey1 == null);

    }

    private OIDCKeyPair getOidcKeyPair() throws JoseException {
        OIDCRsaKeyPairGenerator keyPairGenerator = new OIDCRsaKeyPairGenerator();
        final OIDCKeyPair keyPair = keyPairGenerator.generate();

        assertNotNull(keyPair);
        return keyPair;
    }

    @Test
    public void jsonToPrivateKey() throws Exception {
        final OIDCKeyPair keyPair = getOidcKeyPair();
        final PrivateKey privateKey = OIDCUtils.jsonToPrivateKey(keyPair.privateKeyJson());
        assertNotNull(privateKey);
    }

    @Test
    public void aesEncrypt() throws Exception {

        String data = "Ia mOe {'abc'}";
        final String idToken = OIDCUtils.aesEncrypt(data);
        assertNotNull(idToken);

        final String payload = OIDCUtils.aesDecrypt(idToken);
        assertNotNull(payload);
        assertEquals(payload, data);

    }

    @Test
    public void aesDecrypt() throws Exception {

        String aesKey = "8f53aGKzBUmIeWa38f53aGKzBUmIeWaL";

        String data = "Ia mOe {'abc'} {UJHS";
        final String idToken = OIDCUtils.aesEncrypt(data, aesKey.getBytes());
        assertNotNull(idToken);

        final String payload = OIDCUtils.aesDecrypt(idToken, aesKey.getBytes());
        assertNotNull(payload);
        assertEquals(payload, data);

    }


    @Test
    public void aesDecryptBase64() throws Exception {

        String aesKey = "8f53aGKzBUmIeWa38f53aGKzBUmIeWaL";

        String data = "Ia mOe {'abc'} {UJHS";
        final String idToken = OIDCUtils.aesEncrypt(data, aesKey.getBytes(), true);
        assertNotNull(idToken);

        final String payload = OIDCUtils.aesDecrypt(idToken, aesKey.getBytes(), true);
        assertNotNull(payload);
        assertEquals(payload, data);

    }


}