package com.idsmanager.oidc.p12;

import org.jose4j.base64url.internal.apache.commons.codec.binary.Base64;
import org.jose4j.jws.JsonWebSignature;
import org.testng.annotations.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import static org.testng.Assert.*;

/**
 * @author Shengzhao Li
 */
public class P12IdTokenGeneratorTest {


    /**
     * P12 字符串 获取 privateKey  并生成 id_token
     * <p/>
     * Android 端使用
     *
     * @throws Exception
     */
    @Test(enabled = false)
    public void test() throws Exception {

        String p12Data = "MIIGbAIBAzCCBiYGCSqGSIb3DQEHAaCCBhcEggYTMIIGDzCCAxwGCSqGSIb3DQEHAaCCAw0EggMJMIIDBTCCAwEGCyqGSIb3DQEMCgECoIICsjCCAq4wKAYKKoZIhvcNAQwBAzAaBBRRY78aVb/Yey/JcZChxxk8nWVE7wICBAAEggKA8U7NRQx+FGJ6J4TabBvAo8ezG3skKKqzIlgc53YNAfGPVL+BNHftJv8svEnEAqLLkVZkMSDO9txt5a2UoJYfYi0twdepwWRPk9VW7LHsxSUE8sZI/TuB1aTyd3ZkBmCMy5Cp/qEfowPNopli5Q5UFz/U2ftsTxIuv+3KOxLc4F+EneOZYoJ0xzA4qQsQERp8sFRHQ/Dxg4MF2unsVEHMzX3izlhstXAYlYaWj761/VFsPwFmqqrym+S30R4PuHTtBvRPH74DOd5RllTNZmEv6MR17X55RiiVuGsdMLHQhrLK8iMM9dPrkfh6XwHrDR3JD/sUhlsTojU3LZHERUz68J7Zfk/o1eWKuIPKu+MF28dBSjfQolz+FBCnEaHw/a00QG/yig9EPiIuhZjoCHjgN0WxcY/Q79Nvpgpl30uDoBpqVjmNCCAZnte4ZKQHyKQnX0lH0vjlJCsaI2jIKmT09PmljZsVcy1RaFtkNz7xFQ9aZGWVT/oCfMW/VaUugLp2welGZkfhtnrRRvEiOg6kk5/NpULoYKxadCISZrU8HPP6JvirQF9V/LTq4CYcx4aBlC8AZQ1qSFpvR2ISU7XSb4epgwt4FWG3TEOCuAjIvi9sT7IRv5GZik45B44pB2SY6OgDzragv3L0pl2e9d5uQlmg4bRll3Sm9xsMwNlR++gSBhQ3Rm3MOvM4MqY/GKPZyZxXqOOHNpiVJv1PKnfKY2GIhRLuSoYvetwtfs2D9gKWGBVo6XKzVrEQXIAnSusPIn9ap2ze5suNcNY9OevF8Z0SJndd80KY0lE4YPpDFLLr7gljt1w7e9miwHwRt+oRCUQzqKfEzerNM9dDuNT91TE8MBcGCSqGSIb3DQEJFDEKHggAdABlAHMAdDAhBgkqhkiG9w0BCRUxFAQSVGltZSAxNDc5OTg1NzEyNDUzMIIC6wYJKoZIhvcNAQcGoIIC3DCCAtgCAQAwggLRBgkqhkiG9w0BBwEwKAYKKoZIhvcNAQwBBjAaBBSacykXT4pr5Odu8zBLCUTIxgsksgICBACAggKY1ClK7d7lfd9BcQ2s451OW3nIn/TzWEBwygtnnNrwBzM45fMIdqOgaRS/lean8a/MQe93lkktl/e3/UjTbRCnJyxWsN3u5Btq47G4rWg26Sf9aJH3leyErosXCxoxg0rAaOHqECz7y6k6hLjtGyyTzptUuvNuwf+jbELkzRk2bPly1R963nmr7Ha8yaN4/kcrzVrfwTjO+Wf0piqrGfMZgxFKgiTku9MKl3YSV+ZclIreHPMg4YV9P5X6/Mevrl4psFY30X7/A2+NQCNmQsGXEgZI9o1vt3nv6BgW0YQ+3zs3UJ1BHCai6C7JNInEHee/bttZWzCnxiU/q5UXsMy9PY0sHDe3xp8QSOaSgPLAtIQWqn7boPWgBUKL7YjuAugU5T+S1/q9fxZrbcw3uZaYExNh8OIjEpD6a2WtM/fMw6miKtk0z+0Drbss1PdJGMcUPW4aOI1948Pujekajr2PRBEC02/A29aylAB5VhB/bXoBi7v4iEJJ4eJbsmjLGWqJSvoEbZ72rGaZWyYlqfPJBaEIsrc7j9HYVNR777xn3vGqOF9Qpz0Ce3jf5OQKh/vYXfhEijrbgfzcg2yf7LX3c50y+vbtRJhQLmWF9yD7fwR21hvTT3po9Boon3Lo2l+xBYZhp7JJtpHKwQlFrqiX2A68fXXMMb/4r7WHgCqTw7ChzL0p3dZjL/uSfxpYnE3oR5cqt8Tij85q4OUHt5kIM761Nkp/u18gbfwhny1ZO5n85Daxljpqk369Vq297f/xsq6Nlxxf/9yJ6NGdULSzezBRhaAnXpMuIchQ7pjx8pHAueSDphQBVizFdUS2vIC9i8Kid/hWRZHBVC+DK3ayCGCqlFvGqIzagUajCUDntZeujRbNK3z86jA9MCEwCQYFKw4DAhoFAAQU6Z2EmgTTVsAv1auYeCNdgnr3bwIEFD1O0GUKSwFqYzrUnr4kafEUt2tiAgIEAA==";
        String pwd = Base64.encodeBase64String("dGVzdDEwMjQ=".getBytes("UTF-8"));

        final byte[] bytes = Base64.decodeBase64(p12Data);


        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        InputStream is = new ByteArrayInputStream(bytes);
        keyStore.load(is, pwd.toCharArray());

        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final PrivateKey privateKey = (PrivateKey) keyStore.getKey(alias, pwd.toCharArray());

            Map<String, Object> map = new HashMap<>();
            P12IdTokenGenerator generator = new P12IdTokenGenerator(privateKey, map);
            final String idToken = generator.generate();
            assertNotNull(idToken);
        }

//        Map<String, Object> map = new HashMap<>();
//        P12IdTokenGenerator generator = new P12IdTokenGenerator(privateKey, map);
//        final String idToken = generator.generate();
//
//        assertNotNull(idToken);

    }


    /**
     * P12  privateKey 文件生成 id_token
     *
     * @throws Exception
     */
    @Test
    public void p12IdToken() throws Exception {

        InputStream is = this.getClass().getClassLoader().getResourceAsStream("mm23456.p12");

        final String pwd = "mm23456";
        final PrivateKey privateKey = P12Utils.getPrivateKeysFromP12(is, pwd).get(0);

        byte[] keyData = privateKey.getEncoded();
        String strKeyData = Base64.encodeBase64String(keyData);
        assertNotNull(strKeyData);
//        System.out.println(strKeyData);

//        final String cerift = Cert.BEGIN_CERTIFICATE + "\n" + strKeyData + Cert.END_CERTIFICATE;


//        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(strKeyData));
//        final KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//        final PrivateKey pk1 = keyFactory.generatePrivate(keySpec);
//        assertNotNull(pk1);
//        System.out.println(pk1);


        Map<String, Object> map = new HashMap<>();
        P12IdTokenGenerator generator = new P12IdTokenGenerator(strKeyData, map);
        final String idToken = generator.generate();
        assertNotNull(idToken);
//        System.out.println(idToken);

        //Verify

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        InputStream is2 = this.getClass().getClassLoader().getResourceAsStream("mm23456.p12");

//        char[] pwd = "sso2015".toCharArray();
        keyStore.load(is2, pwd.toCharArray());
        is2.close();

        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final Certificate certificate = keyStore.getCertificate(alias);
            final PublicKey publicKey = certificate.getPublicKey();
            assertNotNull(publicKey);

            final JsonWebSignature jws = new JsonWebSignature();
            jws.setCompactSerialization(idToken);

            final String keyId = jws.getKeyIdHeaderValue();
            assertNull(keyId);


            jws.setKey(publicKey);
            final boolean ok = jws.verifySignature();
            assertTrue(ok);

            final String payload = jws.getPayload();
            assertNotNull(payload);

        }

    }


    /**
     * Pfx  privateKey 文件生成 id_token
     *
     * @throws Exception
     */
    @Test
    public void pfxIdToken() throws Exception {

        InputStream is = this.getClass().getClassLoader().getResourceAsStream("12345678.pfx");

        final String pwd = "12345678";
        final PrivateKey privateKey = P12Utils.getPrivateKeysFromP12(is, pwd).get(0);

        byte[] keyData = privateKey.getEncoded();
        String strKeyData = Base64.encodeBase64String(keyData);
        assertNotNull(strKeyData);
//        System.out.println(strKeyData);

//        final String cerift = Cert.BEGIN_CERTIFICATE + "\n" + strKeyData + Cert.END_CERTIFICATE;


//        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.decodeBase64(strKeyData));
//        final KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//        final PrivateKey pk1 = keyFactory.generatePrivate(keySpec);
//        assertNotNull(pk1);
//        System.out.println(pk1);


        Map<String, Object> map = new HashMap<>();
        P12IdTokenGenerator generator = new P12IdTokenGenerator(strKeyData, map);
        final String idToken = generator.generate();
        assertNotNull(idToken);
//        System.out.println(idToken);

        //Verify

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        InputStream is2 = this.getClass().getClassLoader().getResourceAsStream("12345678.pfx");

//        char[] pwd = "sso2015".toCharArray();
        keyStore.load(is2, pwd.toCharArray());
        is2.close();

        final Enumeration<String> aliases = keyStore.aliases();
        while (aliases.hasMoreElements()) {
            final String alias = aliases.nextElement();
            final Certificate certificate = keyStore.getCertificate(alias);
            final PublicKey publicKey = certificate.getPublicKey();
            assertNotNull(publicKey);

            final JsonWebSignature jws = new JsonWebSignature();
            jws.setCompactSerialization(idToken);

            final String keyId = jws.getKeyIdHeaderValue();
            assertNull(keyId);


            jws.setKey(publicKey);
            final boolean ok = jws.verifySignature();
            assertTrue(ok);

            final String payload = jws.getPayload();
            assertNotNull(payload);

        }

    }


}