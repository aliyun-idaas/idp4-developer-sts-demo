#idsmanager-oidc


<p>
    Commons OIDC tool; 包括<code>id_token</code>生成, 校验等
</p>
<p>
    把在阿里API 项目中实现的对OIDC的代码封装, 整理成工具方法调用
</p>

<h3>Dependency</h3>
<ul>
    <li>commons-io  2.4</li>
    <li>slf4j-log4j12  1.7.5</li>
    <li>jose4j  0.5.3</li>
</ul>

<h3>Version</h3>
<ul>
    <li>2017-01-10  V-1.0.1 [tag]</li>
    <li>2017-03-14  V-1.0.2 [tag]</li>
</ul>

