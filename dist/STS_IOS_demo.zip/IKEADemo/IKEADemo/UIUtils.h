//
//  UIUtils.h
//  Weibo51
//
//  Created by wang xinkai on 15/11/14.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef void (^AlertCompletionBlock)(void);
typedef void (^CompletionBlock)(NSString  *resultDic);
typedef void (^WiFiCompletionBlock)(NSDictionary  *resultDic);
@interface UIUtils : NSObject

+(NSString *) formatDateString:(NSString *)dateString;

+(void)showAlertViewWithController:(UIViewController *)controller Title:(NSString *)title And:(NSString *)message complete:(CompletionBlock)resultDic;
+ (CGFloat)getWindowWidth;
+ (CGFloat)getWindowHeight;
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
+ (BOOL)isBlankString:(NSString *)string;
+(void)showActionSheetWithController:(UIViewController *)controller Title:(NSString *)title And:(NSString *)message oldmanApp:(CompletionBlock)oldmanApp kitApp:(CompletionBlock)kitApp;
+ (int64_t)getCurrentTime;
+ (int64_t)getBeijingTime;
+ (NSString *)getTimeWithFormatter:(NSString *)formatt date:(NSDate *)date;

+(NSString *)ret32bitString;
+(int )getMiniteDate;
+(int )getseconds;

+(NSString *)ret16bitString;
+(NSString *)uploadingData: (NSString *)data;
+ (NSString*)dictionaryToJson:(NSDictionary *)dic;
+(NSString *)AES256_Encrypt:(NSString *)password;

+ (SecCertificateRef)getPrivateKeyFromData:(NSData *)p12Data withPassword:(NSString *)password;

+ (NSString *)getWifiName;

+(void)showshow:(NSString *)title content:(NSString *)content View:(UIView *)view complete:(AlertCompletionBlock)finishAlert;

+(NSString *)GETIdtoken:(NSDictionary *)dic;
+(NSString *)getSM2_IdtokenWithP12:(NSString *)p12Path password:(NSString *)p12Password;
+(BOOL)isMobileNumber:(NSString *)mobileNum;

+ (BOOL)checkPassword:(NSString *) password;
+ (BOOL)checkSercert:(NSString *) sercert;
+ (BOOL) validateEmail:(NSString *)email;
+ (BOOL)checkUserName:(NSString *) username;
+(UIImage *)generateQRCode:(NSString *)message withSize:(CGFloat) size;

+(void)imageScale:(UIImage *)icon imageView:(UIImageView *)imageView;

+ (NSString *)MD5:(NSString *)mdStr;

+(NSString *)MD5ForLower16Bate:(NSString *)str;

+(NSString *)queryisvRec:(NSString *)username;

+(NSString*)numArrayToString:(NSArray *)numArrayParam;

+(BOOL)deleteisvRec:(NSString *)username;
+ (int64_t)getDate:(NSString *)str;

//倒计时
+ (NSString  *)getDetailTimeWithTimestamp:(NSInteger)timestamp;
+(BOOL)isNum:(NSString *)checkedNumString;//判断是否是数字
+ (BOOL)validateContactNumber:(NSString *)mobileNum;
+ (BOOL)isPhoneNum:(NSString *)checkedNumString;
+ (BOOL)checkIDCard:(NSString *)identityCard;
+ (BOOL)isVaildRealName:(NSString *)realName;
+(NSDictionary *)deleteNull:(NSDictionary *)dic;
@end
