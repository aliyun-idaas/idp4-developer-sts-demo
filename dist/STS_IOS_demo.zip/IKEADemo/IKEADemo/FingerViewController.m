//
//  FingerViewController.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/4.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "FingerViewController.h"
#import "AppDelegate.h"
#import <NoPasswordSDK/NoPasswordLoginSDK.h>
#import "ToastView.h"
#import "MBProgressHUD/MBProgressHUD.h"
@interface FingerViewController ()
@property(strong,nonatomic) NoPasswordLoginSDK *noPasswordLoginSDK;
@end

@implementation FingerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.noPasswordLoginSDK = [[NoPasswordLoginSDK alloc]initWithIDPServerURL:@"https://idp4.idsmanager.com/" appKey:@"f8e1b650d4508d5e50d870caebb83112h5yvCjU38R0" appSercert:@"RPU7g03AB712IRQ9XJ2poMcEh04esuidgA1tx1FRmt" enterpriseId:@"wceshi"];
    [self vertify:nil];
}
- (IBAction)vertify:(id)sender {

    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hub.label.text = @"登录中....";
    [hub showAnimated:YES];
    [self.noPasswordLoginSDK FingerprintLoginWithSuccess:^(NSDictionary *resultDic) {

        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });
        NSString *code = [resultDic objectForKey:@"code"];
        if (code.intValue == 200) {

            NSDictionary *dataInfoDic = [resultDic objectForKey:@"data"];
            NSDictionary *accessTokenDto = [dataInfoDic objectForKey:@"accessTokenDto"];
            NSString *accessToken = [accessTokenDto objectForKey:@"accessToken"];
            dispatch_async(dispatch_get_main_queue(), ^{
                // UI更新代码
                [[NSNotificationCenter defaultCenter] postNotificationName:@"AuthUnpasswordSuccessNotification" object:nil];
            });
        }
        NSLog(@"%@",resultDic);
    } failure:^(NSDictionary *resultDic) {
        dispatch_async(dispatch_get_main_queue(), ^{
            // UI更新代码
            NSString *message = [resultDic objectForKey:@"message"];
            if (message) {
            [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"message" withDuaration:4.0];
            }
            [self back:nil];
        });
        NSLog(@"%@",resultDic);
    }];
}
- (IBAction)back:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
