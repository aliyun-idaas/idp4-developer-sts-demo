//
//  UIUtils.m
//  Weibo51
//
//  Created by wang xinkai on 15/11/14.
//  Copyright © 2015年 wxk. All rights reserved.
//

#import "UIUtils.h"

//#import <GmsslSDK/SM2_SignIdtoken.h>
#define DeviceScal [UIUtils getWindowWidth]/375

@implementation UIUtils
+ (CGFloat)getWindowWidth
{



    UIWindow *mainWindow = [UIApplication sharedApplication].windows[0];
    return mainWindow.frame.size.width;
}

+ (CGFloat)getWindowHeight
{
    UIWindow *mainWindow = [UIApplication sharedApplication].windows[0];
    return mainWindow.frame.size.height;
}
+(NSString *) formatDateString:(NSString *)dateString{
    //  1. dateString -> NSDate
    //  2. 计算时间差
    //  3. 转换为字符串

    NSString *format =  @"E MMM dd HH:mm:ss zz yyyy";
    NSDate *date = [self dateFromString:dateString withFormat:format];

    NSTimeInterval distance = [[NSDate new] timeIntervalSinceDate:date];

    //    1分钟以内 ： 刚刚
    //    60分钟以内： 几分钟前
    //    60分钟-24小时： 几小时前
    //    >24小时 ： 几天前
    //    >3*24  :  显示日期


    if (distance < 24*60*60) {
        if (distance< 60*60) {
            if (distance<60) {

                return NSLocalizedString(@"IDPInternationa20013", @"刚刚");

            }
            return [NSString stringWithFormat:@"%d%@",(int)distance/60,NSLocalizedString(@"IDPInternationa20012", @"分钟前")];

        }

        return [NSString stringWithFormat:@"%d%@",(int)distance/60/60,NSLocalizedString(@"IDPInternationa20011", @"小时前")];
    }else{

        return [NSString stringWithFormat:@"%d%@",(int)distance/60/60/24,NSLocalizedString(@"IDPInternationa20010", @"天前")];

    }


}

//把日期字符串转换为NSDate  根据日期格式
+(NSDate*) dateFromString:(NSString *)dateString withFormat:(NSString *)format{

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    return  [formatter dateFromString:dateString];
}

+(NSString *) stringFromDate:(NSDate *)date withFormat:(NSString *)format{

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    return  [formatter stringFromDate:date];
}

+(void)showAlertViewWithController:(UIViewController *)controller Title:(NSString *)title And:(NSString *)message complete:(CompletionBlock)resultDic{

    UIAlertController *alertController= [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"绑定账户" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        resultDic(@"确定");
    }];
    [alertController addAction:okAction];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    [controller presentViewController:alertController animated:YES completion:nil];
}

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }

    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}


//判断一个字符串是否为空 或者 只含有空格
+ (BOOL)isBlankString:(NSString *)string
{
    if (string == nil) {
        return YES;
    }
    if (string == NULL) {
        return YES;
    }
    if ([string isEqual:[NSNull null]]) {
        return YES;
    }
    if (string.length == 0) {
        return YES;
    }
    return NO;
}
+(void)showActionSheetWithController:(UIViewController *)controller Title:(NSString *)title And:(NSString *)message oldmanApp:(CompletionBlock)oldmanApp kitApp:(CompletionBlock)kitApp{

    UIAlertController *alertController= [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *oneAction = [UIAlertAction actionWithTitle:@"独居老人" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        oldmanApp(@"独居老人");
    }];
    UIAlertAction *twoAction = [UIAlertAction actionWithTitle:@"药盒" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        kitApp(@"药盒");
    }];
    [alertController addAction:oneAction];
    [alertController addAction:twoAction];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    [controller presentViewController:alertController animated:YES completion:nil];
}

#pragma mark ======获取当前时间戳=======

+ (int64_t)getCurrentTime {

    NSDate *datenow = [NSDate date];

    NSString*timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];

    NSTimeZone*zone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];

    NSInteger interval = [zone secondsFromGMTForDate:datenow];

    NSDate *localeDate = [datenow dateByAddingTimeInterval:interval];

    NSString *timeSpp = [NSString stringWithFormat:@"%f", [localeDate timeIntervalSince1970]];

    return (int64_t)[datenow timeIntervalSince1970]*1000;

}
+ (int64_t)getBeijingTime {

    NSDate *datenow = [NSDate date];

    // NSString*timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];

    NSTimeZone *zone = [NSTimeZone systemTimeZone];

    NSTimeInterval interval = [zone secondsFromGMTForDate:datenow];


    NSDate *localeDate = [datenow dateByAddingTimeInterval:interval];

    // NSString *timeSpp = [NSString stringWithFormat:@"%f", [localeDate timeIntervalSince1970]];

    return (int64_t)[localeDate timeIntervalSince1970]*1000;
    
}
//获取定义时间的时间点
+(NSString *)getTimeWithFormatter:(NSString *)formatt date:(NSDate *)date{

    //    NSDate *date = [NSDate date];
    
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    
    
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    
    [formatter setDateFormat:formatt];
    NSString *DateTime = [formatter stringFromDate:date];
    return DateTime;

}
+(int )getMiniteDate{

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制

    [formatter setDateFormat:@"mm"];

    //现在时间,你可以输出来看下是什么格式

    NSDate *datenow = [NSDate date];

    //----------将nsdate按formatter格式转成nsstring

    NSString *nowtimeStr = [formatter stringFromDate:datenow];

    NSLog(@"nowtimeStr =  %@",nowtimeStr);

    return [nowtimeStr intValue];
}
+(int )getseconds{

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

    // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制

    [formatter setDateFormat:@"ss"];

    //现在时间,你可以输出来看下是什么格式

    NSDate *datenow = [NSDate date];

    //----------将nsdate按formatter格式转成nsstring

    NSString *nowtimeStr = [formatter stringFromDate:datenow];

    NSLog(@"nowtimeStr =  %@",nowtimeStr);

    return [nowtimeStr intValue];
}
+(NSString *)ret32bitString

{

    char data[22];

    for (int x=0;x<22;data[x++] = (char)('A' + (arc4random_uniform(26))));

    return [[NSString alloc] initWithBytes:data length:22 encoding:NSUTF8StringEncoding];

}
+(NSString *)uploadingData: (NSString *)data {

    //  NSString *base64String = [data base64EncodedStringWithOptions:0];
    data = [data stringByReplacingOccurrencesOfString:@"/"
                                           withString:@"_"];
    data = [data stringByReplacingOccurrencesOfString:@"+"

                                           withString:@"-"];
    //NSLog(@"base64String   %@",base64String);
    return data;
}
+ (NSString*)dictionaryToJson:(NSDictionary *)dic

{

    NSError *parseError = nil;

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];

    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];

}


+ (SecCertificateRef)getPrivateKeyFromData:(NSData *)p12Data withPassword:(NSString *)password {
    NSMutableDictionary *options = [[NSMutableDictionary alloc] init];
    SecCertificateRef certificateRef = NULL;
    [options setObject:password forKey:(__bridge id)kSecImportExportPassphrase];
    CFArrayRef items = NULL;// = CFArrayCreate(NULL, 0, 0, NULL);
    OSStatus securityError = SecPKCS12Import((__bridge CFDataRef)p12Data,
                                             (__bridge CFDictionaryRef)options, &items);
    if (securityError == noErr && CFArrayGetCount(items) > 0) {
        CFDictionaryRef identityDict = CFArrayGetValueAtIndex(items, 0);
        SecIdentityRef identityApp =
        (SecIdentityRef)CFDictionaryGetValue(identityDict,
                                             kSecImportItemIdentity);

        SecIdentityCopyCertificate(identityApp, &certificateRef);

        //        securityError = SecIdentityCopyPrivateKey(identityApp, &privateKey);
        if (securityError != noErr) {
            certificateRef = NULL;
        }
    }
    NSLog(@"-------------------- Publick Key Error %d",(int)securityError);
    if (securityError !=noErr) {
        certificateRef = NULL;
        return certificateRef;
    }
    CFRelease(items);
    options = nil;
    p12Data = nil;
    password = nil;
    return certificateRef;
}
#pragma mark 匹配手机号

+(BOOL)isMobileNumber:(NSString *)mobileNum {

    /**
     * 手机号码
     * 移动：134 135 136 137 138 139 147 150 151 152 157 158 159 178 182 183 184 187 188 198
     * 联通：130 131 132 145 155 156 166 171 175 176 185 186
     * 电信：133 149 153 173 177 180 181 189 199
     * 虚拟运营商: 170
     */
    NSString *target = @"^(0|86|17951)?(13[0-9]|15[012356789]|16[6]|19[89]]|17[01345678]|18[0-9]|14[579])[0-9]{8}$";
    NSPredicate *targetPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", target];
    if ([targetPredicate evaluateWithObject:mobileNum]) {
        return YES;
    }

    return NO;


    

}
#pragma mark 匹配邮箱
+ (BOOL) validateEmail:(NSString *)email

{

    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";

    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];

    return [emailTest evaluateWithObject:email];

}
#pragma mark 正则匹配用户密码
+ (BOOL)checkPassword:(NSString *) password
{
    NSString *pattern = @"(?=^.{8,}$)(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z]).*$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", pattern];
    BOOL isMatch = [pred evaluateWithObject:password];
    return isMatch;

}

#pragma mark 正则匹配Sercert
+ (BOOL)checkSercert:(NSString *) sercert
{
    NSString *regex1 =@"[0-9]*";
    NSPredicate *pred1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex1];
    NSString *regex2 =@"[a-zA-Z]*";
    NSPredicate *pred2 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    if ([pred1 evaluateWithObject:sercert]) {
        return YES;
    }
    if ([pred2 evaluateWithObject:sercert]) {
        return YES;
    }
    NSString * regex = @"^[A-Za-z0-9]{16,128}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:sercert];

    return isMatch;

}
+ (BOOL)checkUserName:(NSString *) username
{
    NSString * regex = @"^(?!_)(?!.*?_$)[a-zA-Z0-9_]{4,18}";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:username];

    return isMatch;

}
+(BOOL)isNum:(NSString *)checkedNumString {
    if (checkedNumString.length != 6) {

        return NO;
    }
    checkedNumString = [checkedNumString stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    if(checkedNumString.length > 0) {
        return NO;
    }
    return YES;
}
#pragma mark 正则匹配Sercert
+(UIImage *)generateQRCode:(NSString *)message withSize:(CGFloat) size{

    //二维码滤镜
    CIFilter *filter=[CIFilter filterWithName:@"CIQRCodeGenerator"];
    //恢复滤镜的默认属性
    [filter setDefaults];
    //将字符串转换成NSData
    NSData *data=[message dataUsingEncoding:NSUTF8StringEncoding];
    //通过KVO设置滤镜inputmessage数据
    [filter setValue:data forKey:@"inputMessage"];
    //获得滤镜输出的图像
    CIImage *outputImage = [filter outputImage];
    //改变二维码大小
    CGRect extent = CGRectIntegral(outputImage.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    // 创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:outputImage fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    // 保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];

}
+(void)imageScale:(UIImage *)icon imageView:(UIImageView *)imageView{

    CGSize imageSize = CGSizeMake(30, 30);
    UIGraphicsBeginImageContextWithOptions(imageSize, NO,0.0); //获得用来处理图片的图形上下文。利用该上下文，你就可以在其上进行绘图，并生成图片 ,三个参数含义是设置大小、透明度 （NO为不透明）、缩放（0代表不缩放）
    CGRect imageRect = CGRectMake(0.0, 0.0, imageSize.width, imageSize.height);
    [icon drawInRect:imageRect];
    imageView.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

}

+(NSString *)ret16bitString

{

    char data[16];

    for (int x=0;x<16;data[x++] = (char)('A' + (arc4random_uniform(26))));

    return [[NSString alloc] initWithBytes:data length:16 encoding:NSUTF8StringEncoding];

}

#pragma mark - 16位 小写 
+(NSString *)MD5ForLower16Bate:(NSString *)str{
    NSString *md5Str = [UIUtils MD5:str];
    NSString *string; for (int i=0; i<24; i++) {

        string=[md5Str substringWithRange:NSMakeRange(8, 16)];

    }
    return string;
}
//数字密码 把array里面的数字 串起来,ISV 固定规则
+(NSString*)numArrayToString:(NSArray *)numArrayParam
{
    if( numArrayParam == nil ){
        NSLog(@"在%s中，numArrayParam is nil",__func__);
        return nil;
    }

    NSMutableString *ptxtString = [NSMutableString stringWithCapacity:1];
    [ptxtString appendString:[numArrayParam objectAtIndex:0]];

    for (int i = 1;i < [numArrayParam count] ; i++ ){
        NSString *str = [numArrayParam objectAtIndex:i];
        [ptxtString appendString:[NSString stringWithFormat:@"-%@",str]];

    }
    return  ptxtString;
}
//时间串
+ (int64_t)getDate:(NSString *)str{

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString:str];

    return (int64_t)[date timeIntervalSince1970]*1000;
    
}

+ (NSString  *)getDetailTimeWithTimestamp:(NSInteger)timestamp{
    NSInteger ms = timestamp;
    NSInteger ss = 1;
    NSInteger mi = ss * 60;
    NSInteger hh = mi * 60;
    NSInteger dd = hh * 24;

    // 剩余的
    NSInteger day = ms / dd;// 天
    NSInteger hour = (ms - day * dd) / hh;// 时
    NSInteger minute = (ms - day * dd - hour * hh) / mi;// 分
    NSInteger second = (ms - day * dd - hour * hh - minute * mi) / ss;// 秒

    if (second<10) {
        return [NSString stringWithFormat:@"%zd:0%zd",minute,second];
    }else{
        return [NSString stringWithFormat:@"%zd:%zd",minute,second];
    }
}

//表单请求
+(NSDictionary *)parsingURL:(NSURL *)url{

    NSMutableDictionary *paramsDic = [[NSMutableDictionary alloc] initWithCapacity:0];
    if ([[url scheme] isEqualToString:@"jiuzhou"]) {

        //NSLog(@"RPToken %ld",[url host].length);
        if([[url host] containsString:@"idp2"]){

            NSString *strUrl = [[url absoluteString] stringByReplacingOccurrencesOfString:@"jiuzhou://idp2?" withString:@""];
            if ([UIUtils isBlankString:strUrl]) {

                return @{@"detail":@"error url"};
            }
            NSArray *paramArray = [strUrl componentsSeparatedByString:@"&"];
            for (int i = 0; i < paramArray.count; i++) {
                NSString *str = paramArray[i];
                NSArray *keyArray = [str componentsSeparatedByString:@"="];
                NSString *key = keyArray[0];
                NSString *value = keyArray[1];

                [paramsDic setObject:[value stringByReplacingOccurrencesOfString:@"%20" withString:@""] forKey:key];

            }
            
        }else{

            return @{@"detail":@"error url"};
        }
        return paramsDic;
    }else{

        return @{@"detail":@"error url"};
    }
    return paramsDic;
    

}
+(void)openHtmlURL:(NSString *)htmlString view:(UIView *)view switch_url:(NSString *)switch_url{

    UIWebView *webview=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    // webview.hidden = YES;
    [view addSubview:webview];

    [webview loadHTMLString:htmlString baseURL:nil];
}
+(BOOL)isPhoneNum:(NSString *)checkedNumString {
    checkedNumString = [checkedNumString stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    if(checkedNumString.length > 0) {
        return NO;
    }
    return YES;
}

+ (BOOL)validateContactNumber:(NSString *)mobileNum{
    /**
     * 手机号码
     * 移动：134[0-8],135,136,137,138,139,150,151,157,158,159,182,183,187,188
     * 联通：130,131,132,152,155,156,185,186
     * 电信：133,1349,153,180,189
     */ NSString * MOBILE = @"^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$";
    /**
     * 中国移动：China Mobile
     * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     */ NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[2378])\\d)\\d{7}$";
    /**
     * 中国联通：China Unicom
     * 130,131,132,152,155,156,175,176,185,186
     */ NSString * CU = @"^1(3[0-2]|5[256]|7[56]|8[56])\\d{8}$";
    /**
     * 中国电信：China Telecom
     * 133,1349,153,177,180,189
     */
    NSString * CT = @"^1((33|53|77|8[09])[0-9]|349)\\d{7}$";
    /**
     * 大陆地区固话及小灵通
     * 区号：010,020,021,022,023,024,025,027,028,029
     * 号码：七位或八位
     */
    NSString * PHS = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    NSPredicate *regextestPHS = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", PHS];
    if(([regextestmobile evaluateWithObject:mobileNum] == YES) || ([regextestcm evaluateWithObject:mobileNum] == YES) || ([regextestct evaluateWithObject:mobileNum] == YES) || ([regextestcu evaluateWithObject:mobileNum] == YES) || ([regextestPHS evaluateWithObject:mobileNum] == YES)){

        return YES;

    }else{
        return NO;

    }
}
+ (BOOL)checkIDCard:(NSString *)identityCard {
    //判断是否为空
    if (identityCard==nil||identityCard.length <= 0) {
        return NO;
    }
    //判断是否是18位，末尾是否是x
    NSString *regex2 = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *identityCardPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex2];
    if(![identityCardPredicate evaluateWithObject:identityCard]){
        return NO;
    }
    //判断生日是否合法
    NSRange range = NSMakeRange(6,8);
    NSString *datestr = [identityCard substringWithRange:range];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat : @"yyyyMMdd"];
    if([formatter dateFromString:datestr]==nil){
        return NO;
    }

    //判断校验位
    if(identityCard.length==18)
    {
        NSArray *idCardWi= @[ @"7", @"9", @"10", @"5", @"8", @"4", @"2", @"1", @"6", @"3", @"7", @"9", @"10", @"5", @"8", @"4", @"2" ]; //将前17位加权因子保存在数组里
        NSArray * idCardY=@[ @"1", @"0", @"10", @"9", @"8", @"7", @"6", @"5", @"4", @"3", @"2" ]; //这是除以11后，可能产生的11位余数、验证码，也保存成数组
        int idCardWiSum=0; //用来保存前17位各自乖以加权因子后的总和
        for(int i=0;i<17;i++){
            idCardWiSum+=[[identityCard substringWithRange:NSMakeRange(i,1)] intValue]*[idCardWi[i] intValue];
        }

        int idCardMod=idCardWiSum%11;//计算出校验码所在数组的位置
        NSString *idCardLast=[identityCard substringWithRange:NSMakeRange(17,1)];//得到最后一位身份证号码

        //如果等于2，则说明校验码是10，身份证号码最后一位应该是X
        if(idCardMod==2){
            if([idCardLast isEqualToString:@"X"]||[idCardLast isEqualToString:@"x"]){
                return YES;
            }else{
                return NO;
            }
        }else{
            //用计算出的验证码与最后一位身份证号码匹配，如果一致，说明通过，否则是无效的身份证号码
            if([idCardLast intValue]==[idCardY[idCardMod] intValue]){
                return YES;
            }else{
                return NO;
            }
        }
    }
    return NO;
}
// 姓名校验 2~8个中文字,不允许拼音,数字
+ (BOOL)isVaildRealName:(NSString *)realName
{
    if ([UIUtils isBlankString:realName]) return NO;

    NSRange range1 = [realName rangeOfString:@"·"];
    NSRange range2 = [realName rangeOfString:@"•"];
    if(range1.location != NSNotFound ||   // 中文 ·
       range2.location != NSNotFound )    // 英文 •
    {
        //一般中间带 `•`的名字长度不会超过15位，如果有那就设高一点
        if ([realName length] < 2 || [realName length] > 15)
        {
            return NO;
        }
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"^[\u4e00-\u9fa5]+[·•][\u4e00-\u9fa5]+$" options:0 error:NULL];

        NSTextCheckingResult *match = [regex firstMatchInString:realName options:0 range:NSMakeRange(0, [realName length])];

        NSUInteger count = [match numberOfRanges];

        return count == 1;
    }
    else
    {
        //一般正常的名字长度不会少于2位并且不超过8位，如果有那就设高一点
        if ([realName length] < 2 || [realName length] > 8) {
            return NO;
        }
        NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"^[\u4e00-\u9fa5]+$" options:0 error:NULL];

        NSTextCheckingResult *match = [regex firstMatchInString:realName options:0 range:NSMakeRange(0, [realName length])];

        NSUInteger count = [match numberOfRanges];

        return count == 1;
    }
}
+(NSDictionary *)deleteNull:(NSDictionary *)dic{

    NSMutableDictionary *mutableDic = [[NSMutableDictionary alloc] init];
    for (NSString *keyStr in dic.allKeys) {

        if ([[dic objectForKey:keyStr] isEqual:[NSNull null]]) {

            [mutableDic setObject:@"" forKey:keyStr];
        }
        else{

            [mutableDic setObject:[dic objectForKey:keyStr] forKey:keyStr];
        }
    }
    return mutableDic;
}
@end

@implementation NSURLRequest(DataController)

+ (BOOL)allowsAnyHTTPSCertificateForHost:(NSString *)host{

    return YES;
}

@end

