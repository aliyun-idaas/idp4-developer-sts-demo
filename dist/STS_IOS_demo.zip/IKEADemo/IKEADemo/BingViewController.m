//
//  BingViewController.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/11.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "BingViewController.h"
#import <NoPasswordSDK/NoPasswordLoginSDK.h>
#import "MBProgressHUD/MBProgressHUD.h"
#import "ToastView.h"
#import "UIUtils.h"
#import "RegisterViewController.h"
@interface BingViewController ()
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property(strong,nonatomic) NoPasswordLoginSDK *noPasswordLoginSDK;

@end

@implementation BingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.noPasswordLoginSDK = [[NoPasswordLoginSDK alloc]initWithIDPServerURL:@"https://idp4.idsmanager.com/" appKey:@"f8e1b650d4508d5e50d870caebb83112h5yvCjU38R0" appSercert:@"RPU7g03AB712IRQ9XJ2poMcEh04esuidgA1tx1FRmt" enterpriseId:@"wceshi"];
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self.titleLabel.text];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];

    [paragraphStyle setLineSpacing:10];//调整行间距

    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [self.titleLabel.text length])];
    self.titleLabel.attributedText = attributedString;
    [self.titleLabel sizeToFit];
}
- (IBAction)bingUser:(id)sender {
    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hub.label.text = @"绑定中....";
    [hub showAnimated:YES];
    [self.username resignFirstResponder];
    [self.password resignFirstResponder];
    if ([UIUtils isBlankString:self.username.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入用户名" withDuaration:4.0];
        return;
    }
    if ([UIUtils isBlankString:self.password.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入密码" withDuaration:4.0];
        return;
    }
    [self.noPasswordLoginSDK wxBindingIDPAuthLoginWithUserName:self.username.text idp_cred:self.password.text enterpriseAuthId:@"wceshiwechat" userId:self.openId clientId:@"93546bee7d6f4df4a6f19c3b40af4cf8RwTwiUfrCmi" otherData:self.dic success:^(NSDictionary *resultDic) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];


        NSString *code = [resultDic objectForKey:@"code"];
        if (code.intValue == 200){
                // UI更新代码
                [[NSNotificationCenter defaultCenter] postNotificationName:@"AuthUnpasswordSuccessNotification" object:nil];
        }
        });
        NSLog(@"resultDic %@",resultDic);

    } failure:^(NSDictionary *resultDic) {
        NSLog(@"resultDic %@",resultDic);
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
        });
    }];

}
- (IBAction)back:(id)sender {

     [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)register:(id)sender {

    RegisterViewController *registerController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"RegisterView"];
    registerController.openId = self.openId;
    registerController.userInfoDic = self.dic;
    [self.navigationController pushViewController:registerController animated:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
