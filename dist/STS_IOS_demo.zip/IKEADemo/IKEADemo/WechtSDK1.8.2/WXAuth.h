//
//  WXAuth.h
//  hongyantub2b
//
//  Created by Apple on 2018/8/23.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#pragma mark - WXApiDelegate

@protocol WXUserInfoApiDelegate <NSObject>
@optional
/**
 * @brief 回调出微信授权成功信息.
 */
-(void) WXOnReqUsrInfo:(NSDictionary *)dic;

/**
 * @brief 回调出微信授权失败信息.
 */
-(void)WXOAuthFail:(NSDictionary *)dic;
@end
#define  WXAUTH [WXAuth sharedInstance]
@interface WXAuth : NSObject
@property(nonatomic,assign)id<WXUserInfoApiDelegate> delegate;
@property(nonatomic,strong)NSString *appId;
@property(nonatomic,strong)NSString *appSecret;
/**
 * @brief 初始化.
 */
+ (WXAuth *)sharedInstance;

/*! @brief WXApi的成员函数，向微信终端程序注册第三方应用。
 *
 * 需要在每次启动第三方应用程序时调用。第一次调用后，会在微信的可用应用列表中出现。
 * iOS7及以上系统需要调起一次微信才会出现在微信的可用应用列表中。
 * @attention 请保证在主线程中调用此函数
 * @param appid 微信开发者ID
 * @return 成功返回YES，失败返回NO。
 */
-(BOOL)registerApp:(NSString *)appid;
/*! @brief 处理微信通过URL启动App时传递的数据
 *
 * 需要在 application:openURL:sourceApplication:annotation:或者application:handleOpenURL中调用。
 * @param url 微信启动第三方应用时传递过来的URL
 * @return 成功返回YES，失败返回NO。
 */
- (BOOL)handleOpenURL:(NSURL *)url;
/*! @brief 发送请求到微信，等待微信返回onResp
 *
 * 函数调用后，会切换到微信的界面。第三方应用程序等待微信返回onResp。微信在异步处理完成后一定会调用onResp。支持以下类型
 */
- (void)sendWXAuthReq;
@end
