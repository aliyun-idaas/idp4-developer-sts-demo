//
//  BingViewController.h
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/11.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BingViewController : UIViewController

@property(strong,nonatomic)NSDictionary *dic;
@property(strong,nonatomic)NSString *openId;

@end

NS_ASSUME_NONNULL_END
