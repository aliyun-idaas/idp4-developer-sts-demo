//
//  MyViewController.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/3.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "MyViewController.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import "ToastView.h"
#import "MBProgressHUD/MBProgressHUD.h"
#import "SDWebImage/UIImageView+WebCache.h"
@interface MyViewController ()
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *nickName;

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.parentViewController.navigationItem.title = @"宜家会员中心";



    // Do any additional setup after loading the view.

}
- (IBAction)logout:(id)sender {
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"IKEADemoLogin"] != nil) {

        NSString *islogin = [[NSUserDefaults standardUserDefaults]objectForKey:@"IKEADemoLogin"];


        if ([islogin isEqualToString:@"YES"]) {
            MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            hub.label.text = @"退出中....";
            [hub showAnimated:YES];

            [self performSelector:@selector(hiddeView) withObject:nil afterDelay:2.0];

        }else{

            ViewController *loginController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"LoginView"];
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginController];

            [self presentViewController:nav animated:YES completion:nil];
        }
    }

}
- (void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    NSString *headimgurl = [[NSUserDefaults standardUserDefaults]objectForKey:@"headimgurl"];
    NSString *nickname = [[NSUserDefaults standardUserDefaults]objectForKey:@"nickname"];

    self.nickName.text = @"";

    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"IKEADemoLogin"] != nil) {

        NSString *islogin = [[NSUserDefaults standardUserDefaults]objectForKey:@"IKEADemoLogin"];

        if ([islogin isEqualToString:@"NO"]) {

            [self.loginButton setTitle:@"马上登录" forState:UIControlStateNormal];
        }else{
            if (headimgurl) {
                [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:headimgurl] placeholderImage:[UIImage imageNamed:@"logo"] options:nil];
                self.nickName.text = nickname;
            }else{

                self.nickName.text = @"";
                self.headerImageView.image = [UIImage imageNamed:@"logo"];
            }
            [self.loginButton setTitle:@"退出登录" forState:UIControlStateNormal];
        }
    }
    self.parentViewController.navigationItem.title = @"宜家会员中心";
}
-(void)hiddeView{

    [MBProgressHUD hideHUDForView:self.view animated:YES];
    [self.loginButton setTitle:@"马上登录" forState:UIControlStateNormal];
    [[NSUserDefaults standardUserDefaults]setObject:@"NO"  forKey:@"IKEADemoLogin"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"headimgurl"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"nickname"];
    self.headerImageView.image = [UIImage imageNamed:@"logo"];
    self.nickName.text = @"";
    [[NSUserDefaults standardUserDefaults] synchronize];
    [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"退出登录成功" withDuaration:4.0];
}
/*
 #pragma mark - Navigation

 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
