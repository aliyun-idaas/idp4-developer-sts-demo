//
//  ViewController.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/3.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import <NoPasswordSDK/NoPasswordLoginSDK.h>
#import "ToastView.h"
#import "FingerViewController.h"
#import "MBProgressHUD/MBProgressHUD.h"
#import "WechtSDK1.8.2/WXAuth.h"
#import "UIUtils.h"
#import "BingViewController.h"
#import "KeychainItemWrapper.h"
@interface ViewController ()<WXUserInfoApiDelegate>
@property (weak, nonatomic) IBOutlet UIButton *exchangeLoginButton;
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property(strong,nonatomic) NoPasswordLoginSDK *noPasswordLoginSDK;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    self.exchangeLoginButton.layer.borderWidth = 0.5;
    self.exchangeLoginButton.layer.borderColor = [UIColor colorWithRed:247.0/255.0 green:97.0/255.0 blue:50.0/255.0 alpha:1.0].CGColor;
    self.noPasswordLoginSDK = [[NoPasswordLoginSDK alloc]initWithIDPServerURL:@"https://idp4.idsmanager.com/" appKey:@"f8e1b650d4508d5e50d870caebb83112h5yvCjU38R0" appSercert:@"RPU7g03AB712IRQ9XJ2poMcEh04esuidgA1tx1FRmt" enterpriseId:@"wceshi"];
    [WXAuth sharedInstance].appId = @"wx520d50135e0b48fd";
    [WXAuth sharedInstance].appSecret = @"0d27206d23139a38772d54369a9b271e";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(AuthUnpasswordSuccess) name:@"AuthUnpasswordSuccessNotification" object:nil];

}
- (void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    KeychainItemWrapper * accountKeychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"AccountKeychainItemKey" accessGroup:nil];
    NSString * stored_username = [accountKeychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
    if (stored_username.length != 0) {

        self.username.text = stored_username;
    }


}
-(void)AuthUnpasswordSuccess{
    [[NSUserDefaults standardUserDefaults]setObject:@"YES"  forKey:@"IKEADemoLogin"];

    [[NSUserDefaults standardUserDefaults] synchronize];
    UITabBarController *tabBarController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TabBar"];
    UINavigationController *mainNav = [[UINavigationController alloc]initWithRootViewController:tabBarController];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    delegate.window.rootViewController = mainNav;
    [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"登录成功" withDuaration:4.0];
}
- (IBAction)login:(id)sender {

    [self.username resignFirstResponder];
    [self.password resignFirstResponder];
    if ([ViewController isBlankString:self.username.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入用户名" withDuaration:4.0];

        return;
    }
    if ([ViewController isBlankString:self.password.text]) {
        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入密码" withDuaration:4.0];
        return;
    }
    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hub.label.text = @"登录中....";
    [hub showAnimated:YES];

    [self.noPasswordLoginSDK loginWthUsername:self.username.text password:self.password.text success:^(NSDictionary *resultDic) {

        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });
        NSString *code = [resultDic objectForKey:@"code"];
        if (code.intValue == 200) {

            NSDictionary *dataInfoDic = [resultDic objectForKey:@"data"];
            NSDictionary *accessTokenDto = [dataInfoDic objectForKey:@"accessTokenDto"];
            NSString *accessToken = [accessTokenDto objectForKey:@"accessToken"];
            [[NSUserDefaults standardUserDefaults]setObject:@"YES"  forKey:@"IKEADemoLogin"];

            [[NSUserDefaults standardUserDefaults] synchronize];
            // UI更新代码
            dispatch_async(dispatch_get_main_queue(), ^{
                
                UITabBarController *tabBarController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"TabBar"];
                UINavigationController *mainNav = [[UINavigationController alloc]initWithRootViewController:tabBarController];


                AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;

                delegate.window.rootViewController = mainNav;

                KeychainItemWrapper * accountKeychainItem = [[KeychainItemWrapper alloc] initWithIdentifier:@"AccountKeychainItemKey" accessGroup:nil];
                NSString * stored_username = [accountKeychainItem objectForKey:(__bridge id)(kSecAttrAccount)];
                 dispatch_async(dispatch_get_main_queue(), ^{

                [accountKeychainItem setObject:@"AccountKeychainItemKey" forKey:(__bridge id)kSecAttrService];
                [accountKeychainItem setObject:self.username.text forKey:(__bridge id)kSecAttrAccount];
                [accountKeychainItem setObject:@"" forKey:(__bridge id)kSecValueData];
                 });

                if (stored_username.length != 0) {

                    if (stored_username != self.username.text) {
                        [self.noPasswordLoginSDK DownLoadCertificateByPwdWithUsername:self.username.text pwd:self.password.text success:^(NSDictionary *resultDic) {
                            NSString *code = [resultDic objectForKey:@"errorNumber"];
                            if (code.integerValue == 0) {
                                // UI更新代码

                                dispatch_async(dispatch_get_main_queue(), ^{

                                    [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"已默认开启指纹安全认证，您可以使用指纹免密登录" withDuaration:4.0];
                                });
                            }
                            NSLog(@"%@",resultDic);

                        } failure:^(NSDictionary *resultDic) {
                            NSLog(@"%@",resultDic);
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [MBProgressHUD hideHUDForView:self.view animated:YES];
                                [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
                            });

                        }];
                        return ;
                    }

                }

                if (![NoPasswordLoginSDK isExistCertificate]) {

                    [self.noPasswordLoginSDK DownLoadCertificateByPwdWithUsername:self.username.text pwd:self.password.text success:^(NSDictionary *resultDic) {
                        NSString *code = [resultDic objectForKey:@"errorNumber"];
                        if (code.integerValue == 0) {
                            // UI更新代码
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"已默认开启指纹安全认证，您可以使用指纹免密登录" withDuaration:4.0];
                            });
                        }
                        NSLog(@"%@",resultDic);

                    } failure:^(NSDictionary *resultDic) {
                        NSLog(@"%@",resultDic);
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [MBProgressHUD hideHUDForView:self.view animated:YES];
                            [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
                        });

                    }];
                }else{

                    // UI更新代码
                    [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"已默认开启指纹安全认证，您可以使用指纹免密登录" withDuaration:4.0];

                }
            });
        }
        NSLog(@"%@",resultDic);

    } failure:^(NSDictionary *resultDic) {
        NSLog(@"%@",resultDic);
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *code = [resultDic objectForKey:@"code"];
            if (code.intValue == 501) {
                [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"用户名或密码错误" withDuaration:4.0];

            }else if (code.intValue == 601){
                [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"当前账户已绑定其他设备" withDuaration:4.0];
            }

            [MBProgressHUD hideHUDForView:self.view animated:YES];
        });

    }];


}
- (IBAction)wxLogin:(id)sender {

    //微信授权登录
    [WXAUTH sendWXAuthReq];
    [WXAuth sharedInstance].delegate = self;
}


- (IBAction)exchangeLogin:(id)sender {
    [self.username resignFirstResponder];
    [self.password resignFirstResponder];
    if ([NoPasswordLoginSDK isExistCertificate]) {

        FingerViewController *fingerController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"FingerprintUnlock"];
        //UINavigationController *mainNav = [[UINavigationController alloc]initWithRootViewController:fingerController];
        [self presentViewController:fingerController animated:YES completion:nil];
    }else{

        // UI更新代码
        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"首次登录请使用用户名、密码登录" withDuaration:4.0];
    }

}
+(void)showAlertViewWithController:(UIViewController *)controller Title:(NSString *)title And:(NSString *)message complete:(CompletionBlock)resultDic{

    UIAlertController *alertController= [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        resultDic(@"确定");
    }];
    [alertController addAction:okAction];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    [controller presentViewController:alertController animated:YES completion:nil];
}
//判断一个字符串是否为空 或者 只含有空格
+ (BOOL)isBlankString:(NSString *)string
{
    if (string == nil) {
        return YES;
    }
    if (string == NULL) {
        return YES;
    }
    if ([string isEqual:[NSNull null]]) {
        return YES;
    }
    if (string.length == 0) {
        return YES;
    }
    return NO;
}
- (IBAction)back:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark --------- 微信登录状态回调 ------
-(void)WXOnReqUsrInfo:(NSDictionary *)dic{

    NSLog(@"dic %@",dic);

    [self getWechatUserInfoWithAccessToken:[dic objectForKey:@"access_token"] openId:[dic objectForKey:@"openid"]];
    
}
//根据accesstoken和openid获取用户信息

- (void)getWechatUserInfoWithAccessToken:(NSString *)accessToken openId:(NSString *)openId{
    NSString *url =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@",accessToken,openId];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        NSURL *zoneUrl = [NSURL URLWithString:url];

        NSString *zoneStr = [NSString stringWithContentsOfURL:zoneUrl encoding:NSUTF8StringEncoding error:nil];

        NSData *data = [zoneStr dataUsingEncoding:NSUTF8StringEncoding];

        dispatch_async(dispatch_get_main_queue(), ^{

            if (data)
            {
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                                    options:NSJSONReadingMutableContainers error:nil];
                NSLog(@"%@",dic);

                NSString *openId = [dic objectForKey:@"openid"];

                NSString *memNickName = [dic objectForKey:@"nickname"];

                NSString *memSex = [dic objectForKey:@"sex"];

                NSString *headimgurl = [dic objectForKey:@"headimgurl"];
                NSLog(@"--%@--%@--%@",openId,memNickName,memSex);
                [[NSUserDefaults standardUserDefaults]setObject:headimgurl forKey:@"headimgurl"];
                [[NSUserDefaults standardUserDefaults]setObject:memNickName forKey:@"nickname"];
                [[NSUserDefaults standardUserDefaults]synchronize];

                [self.noPasswordLoginSDK wxquickAuthLoginWithUserInfo:openId clientId:@"93546bee7d6f4df4a6f19c3b40af4cf8RwTwiUfrCmi" enterpriseAuthId:@"wceshiwechat" success:^(NSDictionary *resultDic) {
                    NSString *code = [resultDic objectForKey:@"code"];
                    if (code.intValue == 200){
                        dispatch_async(dispatch_get_main_queue(), ^{
                        [self AuthUnpasswordSuccess];
                        });

                    }
                    NSLog(@"message %@",resultDic);

                } failure:^(NSDictionary *resultDic) {
                    NSString *code = [resultDic objectForKey:@"code"];
                    if (code.intValue == 103){
                        dispatch_async(dispatch_get_main_queue(), ^{

                            //[UIUtils showAlertViewWithController:self Title:@"提示" And:@"您还未绑定IDP4账户，绑定成功之后" complete:^(NSString *resultDic) {
                                BingViewController *bingController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"BingView"];
                                bingController.openId = openId;
                                bingController.dic = dic;
                                UINavigationController *mainNav = [[UINavigationController alloc]initWithRootViewController:bingController];
                                [self presentViewController:mainNav animated:YES completion:nil];

                          //  }];

                        });

                        return ;
                    }
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
                    });
                    NSLog(@"error %@",resultDic);
                }];


            }

        });



    });

}

#pragma mark ---------公共方法------
+(NSString *)convertToJsonData:(NSDictionary *)dict
{

    NSError *error;

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];

    NSString *jsonString;

    if (!jsonData) {

        //NSLog(@"%@",error);

    }else{

        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];

    }

    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];

    NSRange range = {0,jsonString.length};

    //去掉字符串中的空格

    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];

    NSRange range2 = {0,mutStr.length};

    //去掉字符串中的换行符

    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];

    return mutStr;

}
@end
