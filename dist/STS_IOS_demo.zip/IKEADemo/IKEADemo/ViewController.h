//
//  ViewController.h
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/3.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^CompletionBlock)(NSString  *resultDic);
@interface ViewController : UIViewController


@end

