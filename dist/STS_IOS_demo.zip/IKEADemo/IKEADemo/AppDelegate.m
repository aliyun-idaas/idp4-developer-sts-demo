//
//  AppDelegate.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/3.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "AppDelegate.h"
#import "WechtSDK1.8.2/WXAuth.h"
#import <IQKeyboardManager/IQKeyboardManager.h>
#define WXAppId            @"wx520d50135e0b48fd"//填上应用的AppID
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"IKEADemoLogin"] == nil) {
        
        [[NSUserDefaults standardUserDefaults]setObject:@"NO" forKey:@"IKEADemoLogin"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager];
    keyboardManager.enable = YES;
    keyboardManager.shouldResignOnTouchOutside = YES;
    keyboardManager.shouldToolbarUsesTextFieldTintColor = YES;
    keyboardManager.toolbarManageBehaviour = IQAutoToolbarBySubviews;
    keyboardManager.toolbarPreviousBarButtonItemText = @"上一个";
    keyboardManager.toolbarNextBarButtonItemText = @"下一个";
    keyboardManager.toolbarDoneBarButtonItemText = @"完成";
    keyboardManager.enableAutoToolbar = YES;
    keyboardManager.shouldShowToolbarPlaceholder = YES;
    keyboardManager.keyboardDistanceFromTextField = 10.0;

    //微信注册
    [WXAUTH registerApp:WXAppId];

    return YES;
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {

    if([url.host isEqualToString:@"platformId=wechat"] || [url.host isEqualToString:@"oauth"]){

        return [WXAUTH handleOpenURL:url];
    }
    return YES;

}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{

    if([url.host isEqualToString:@"platformId=wechat"] || [url.host isEqualToString:@"oauth"]){

        return [WXAUTH handleOpenURL:url];
    }
     return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{

    if([url.host isEqualToString:@"platformId=wechat"] || [url.host isEqualToString:@"oauth"]){

        return [WXAUTH handleOpenURL:url];
    }
     return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
