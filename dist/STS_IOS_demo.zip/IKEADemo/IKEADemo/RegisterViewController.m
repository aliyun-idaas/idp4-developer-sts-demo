//
//  RegisterViewController.m
//  IKEADemo
//
//  Created by 九州云腾 on 2019/6/5.
//  Copyright © 2019 九州云腾. All rights reserved.
//

#import "RegisterViewController.h"
#import "UIUtils.h"
#import "ToastView.h"
#import <NoPasswordSDK/NoPasswordLoginSDK.h>
#import "MBProgressHUD/MBProgressHUD.h"
@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *againPassword;
@property(strong,nonatomic) NoPasswordLoginSDK *noPasswordLoginSDK;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
      self.noPasswordLoginSDK = [[NoPasswordLoginSDK alloc]initWithIDPServerURL:@"https://idp4.idsmanager.com/" appKey:@"f8e1b650d4508d5e50d870caebb83112h5yvCjU38R0" appSercert:@"RPU7g03AB712IRQ9XJ2poMcEh04esuidgA1tx1FRmt" enterpriseId:@"wceshi"];
}
- (IBAction)submit:(id)sender {

    if ([UIUtils isBlankString:self.username.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入用户名" withDuaration:4.0];
        return;
    }
    if ([UIUtils isBlankString:self.phoneNumber.text] || ![UIUtils isPhoneNum:self.phoneNumber.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入正确的手机号" withDuaration:4.0];
        return;
    }
    if ([UIUtils isBlankString:self.email.text] || ![UIUtils validateEmail:self.email.text] ){

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入正确的邮箱" withDuaration:4.0];
        return;
    }
    
    if ([UIUtils isBlankString:self.password.text] || [UIUtils isBlankString:self.againPassword.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"请输入密码" withDuaration:4.0];
        return;
    }
    if (![self.password.text isEqualToString:self.againPassword.text]) {

        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"两次密码输入不一致" withDuaration:4.0];
        return;
    }
    [self registerUser];
}
-(void)registerUser{
    MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hub.label.text = @"注册中....";
    [hub showAnimated:YES];
    [self.noPasswordLoginSDK wxRegisterUserName:self.username.text password:self.password.text email:self.email.text phoneNumber:self.phoneNumber.text enterpriseAuthId:@"wceshiwechat" success:^(NSDictionary *resultDic) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            NSString *code = [resultDic objectForKey:@"code"];
            if (code.intValue == 200) {
                [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:@"注册成功" withDuaration:4.0];
                [self.noPasswordLoginSDK wxBindingIDPAuthLoginWithUserName:self.username.text idp_cred:self.password.text enterpriseAuthId:@"wceshiwechat" userId:self.openId clientId:@"93546bee7d6f4df4a6f19c3b40af4cf8RwTwiUfrCmi" otherData:self.userInfoDic success:^(NSDictionary *resultDic) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [MBProgressHUD hideHUDForView:self.view animated:YES];


                        NSString *code = [resultDic objectForKey:@"code"];
                        if (code.intValue == 200){
                            // UI更新代码
                            [[NSNotificationCenter defaultCenter] postNotificationName:@"AuthUnpasswordSuccessNotification" object:nil];
                        }
                    });
                    NSLog(@"resultDic %@",resultDic);
                } failure:^(NSDictionary *resultDic) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                        [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
                    });
                    NSLog(@"error %@",resultDic);
                }];

            }
        });

        NSLog(@"resultDic %@",resultDic);

    } failure:^(NSDictionary *resultDic) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
             [ToastView showToastInParentView:UIApplication.sharedApplication.keyWindow withText:[resultDic objectForKey:@"message"] withDuaration:4.0];
        });
        NSLog(@"error %@",resultDic);
    }];
    
}
- (IBAction)back:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark ---------公共方法------
+(NSString *)convertToJsonData:(NSDictionary *)dict
{

    NSError *error;

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];

    NSString *jsonString;

    if (!jsonData) {

        //NSLog(@"%@",error);

    }else{

        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];

    }

    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];

    NSRange range = {0,jsonString.length};

    //去掉字符串中的空格

    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];

    NSRange range2 = {0,mutStr.length};

    //去掉字符串中的换行符

    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];

    return mutStr;

}
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString
{
    if (jsonString == nil) {
        return nil;
    }

    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err)
    {
        // NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}
@end
