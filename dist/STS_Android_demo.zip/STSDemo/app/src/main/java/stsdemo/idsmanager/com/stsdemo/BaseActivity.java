package stsdemo.idsmanager.com.stsdemo;

import android.support.annotation.LayoutRes;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewStub;
import android.widget.FrameLayout;

/**
 * @author hui
 * @describe
 * @time at 2017/5/24 14:25
 */
public class BaseActivity extends AppCompatActivity {
    ViewStub vsLoading;

    @Override
    public void setContentView(@LayoutRes int layoutResID) {
        super.setContentView(R.layout.activity_base);
        vsLoading = (ViewStub) findViewById(R.id.vs_loading);
        FrameLayout fl = (FrameLayout) findViewById(R.id.base_loading_fl_content);
        fl.addView(LayoutInflater.from(this).inflate(layoutResID, null));
    }

    protected void showLoading() {
        if (vsLoading != null) {
            vsLoading.setVisibility(View.VISIBLE);
        }
    }

    protected void dismissLoading() {
        if (vsLoading != null) {
            vsLoading.setVisibility(View.GONE);
        }
    }
}
