package stsdemo.idsmanager.com.stsdemo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.idsmanager.stslibrary.STS;
import com.idsmanager.stslibrary.callback.TokenCallBack;

import butterknife.Bind;
import butterknife.ButterKnife;

public class LoginActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "LoginActivity";
    @Bind(R.id.btn_get_id_token)
    Button btnLogin;
    @Bind(R.id.et_user_name)
    EditText etUserName;
    @Bind(R.id.et_user_psw)
    EditText etUserPsw;
    @Bind(R.id.et_base_url)
    EditText etBaseUrl;
    @Bind(R.id.tv_bottom_version)
    TextView tvVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        etBaseUrl.clearFocus();
        etUserName.requestFocus();
        tvVersion.setText("Version " + Utils.getVerName(this));
        btnLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btn_get_id_token:
                boolean isOk = checkEditIsEmpty();
                showLoading();
                Utils.closeInput(LoginActivity.this);
                if (isOk) {
                    STS.getInstance().getIdToken(etBaseUrl.getText().toString().trim(), "4dbfb4bfe9bb43f386d473e789db6776eIE2sxJlE7b", "sVWx3VGXD5qmHTBvM6lWcFvOJOUHh5UTllrc7Z8FPr", etUserName.getText().toString().trim(), etUserPsw.getText().toString().trim(), new TokenCallBack() {

                        @Override
                        public String onGetToken(String idToken, String refreshToken) {
                            Log.d(TAG, "idToken-->" + idToken );
                            Log.d(TAG, "refreshToken=" + refreshToken);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    dismissLoading();
                                }
                            });

                            Intent i = new Intent(LoginActivity.this, MainActivity.class);
                            i.putExtra("id_token", idToken);
                            i.putExtra("head_url", etBaseUrl.getText().toString().trim());
                            i.putExtra("username", etUserName.getText().toString().trim());
                            i.putExtra("refreshToken", refreshToken);
                            startActivity(i);
                            return null;
                        }

                        @Override
                        public void onError(int errorCode) {
                            Log.d(TAG, "errorCode-->" + errorCode);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    dismissLoading();
                                }
                            });
                        }

                    });
                    break;
                }
            default:
                break;
        }

    }

//    private void login() {
//        // 2017/5/23 显示进度条，开启网络请求
//        Utils.closeInput(this);
//        NetUtil.BASE_URL = etBaseUrl.getText().toString().trim();
//        String url = NetUtil.BASE_URL + NetUtil.GET_ID_TOKEN;
//        showLoading();
//        OkHttpClient client = new OkHttpClient();
//        MediaType jsonType = MediaType.parse("application/json; charset=utf-8");
//        RequestBody body = RequestBody.create(jsonType, new Gson().toJson(new IdTokenBean("4dbfb4bfe9bb43f386d473e789db6776eIE2sxJlE7b", "sVWx3VGXD5qmHTBvM6lWcFvOJOUHh5UTllrc7Z8FPr", etUserName.getText().toString().trim(), etUserPsw.getText().toString().trim())));
//        Request request = new Request.Builder()
//                .url(url)
//                .post(body)
//                .build();
//        client.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                Log.d(TAG, "e->" + e.getMessage());
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        dismissLoading();
//                        Toast.makeText(LoginActivity.this, R.string.net_error, Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }
//
//            @Override
//            public void onResponse(final Call call, final okhttp3.Response response) throws IOException {
//                final String result = response.body().string();
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        dismissLoading();
//                        int code = response.code();
//                        Gson gson = new Gson();
//                        switch (code) {
//                            case 200:
//                                IdTokenResponse idTokenResponse = gson.fromJson(result, IdTokenResponse.class);
//                                switch (idTokenResponse.getStatusCode()) {
//                                    case 0:
//                                        Intent i = new Intent(LoginActivity.this, MainActivity.class);
//                                        i.putExtra("id_token", idTokenResponse.getId_token());
//                                        startActivity(i);
//                                        break;
//                                    default:
//                                        Toast.makeText(LoginActivity.this, R.string.request_fail, Toast.LENGTH_SHORT).show();
//                                        Log.d(TAG, "idTokenResponse.getStatusCode()-->" + idTokenResponse.getStatusCode());
//                                        break;
//                                }
//                                break;
//                            case 401:
//                                IdTokenResponse idTokenResponseTemp = gson.fromJson(result, IdTokenResponse.class);
//                                switch (idTokenResponseTemp.getStatusCode()) {
//                                    case 400:
//                                        Toast.makeText(LoginActivity.this, R.string.param_error, Toast.LENGTH_SHORT).show();
//                                        break;
//                                    case 501:
//                                        Toast.makeText(LoginActivity.this, R.string.user_name_or_psw_error, Toast.LENGTH_SHORT).show();
//                                        break;
//                                    case 480:
//                                        Toast.makeText(LoginActivity.this, R.string.appkey_or_appSecret_error, Toast.LENGTH_SHORT).show();
//                                        break;
//                                    case 481:
//                                        Toast.makeText(LoginActivity.this, R.string.build_id_token_error, Toast.LENGTH_SHORT).show();
//                                        break;
//                                    case 482:
//                                        Toast.makeText(LoginActivity.this, R.string.app_not_start, Toast.LENGTH_SHORT).show();
//                                        break;
//                                    default:
//                                        Toast.makeText(LoginActivity.this, R.string.request_fail, Toast.LENGTH_SHORT).show();
//                                        Log.d(TAG, "idTokenResponseTemp.getStatusCode()-->" + idTokenResponseTemp.getStatusCode());
//                                        break;
//                                }
//                                break;
//                            default:
//                                Toast.makeText(LoginActivity.this, R.string.request_fail, Toast.LENGTH_SHORT).show();
//                                Log.d(TAG, "code-->" + code);
//                                break;
//                        }
//                    }
//                });
//            }
//        });
//
//    }

    private boolean checkEditIsEmpty() {
        if (TextUtils.isEmpty(etUserName.getText().toString().trim())) {
            Toast.makeText(this, getResources().getString(R.string.user_name_is_empty), Toast.LENGTH_SHORT).show();
            return false;
        }
        if (TextUtils.isEmpty(etUserPsw.getText().toString().trim())) {
            Toast.makeText(this, getResources().getString(R.string.user_psw_is_empty), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
