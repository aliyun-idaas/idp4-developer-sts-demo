package stsdemo.idsmanager.com.stsdemo.application;

import android.app.Application;

import com.idsmanager.stslibrary.STS;

/**
 * describe
 * Created by hui on 2017/5/26.
 */

public class STSApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        STS.init(this);
    }
}
