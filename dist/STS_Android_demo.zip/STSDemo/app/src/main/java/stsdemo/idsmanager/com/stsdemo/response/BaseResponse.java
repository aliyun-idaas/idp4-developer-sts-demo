package stsdemo.idsmanager.com.stsdemo.response;//package stsdemo.idsmanager.com.stsdemoapplication.response;
//
///**
// * describe
// * Created by hui on 2017/5/24.
// */
//
//public class BaseResponse {
//
//    private int statusCode;
//    private String[] errors;
//    private boolean successful;
//
//    public BaseResponse(int statusCode, String[] errors, boolean successful) {
//        this.statusCode = statusCode;
//        this.errors = errors;
//        this.successful = successful;
//    }
//
//    public int getStatusCode() {
//        return statusCode;
//    }
//
//    public void setStatusCode(int statusCode) {
//        this.statusCode = statusCode;
//    }
//
//    public String[] getErrors() {
//        return errors;
//    }
//
//    public void setErrors(String[] errors) {
//        this.errors = errors;
//    }
//
//    public boolean isSuccessful() {
//        return successful;
//    }
//
//    public void setSuccessful(boolean successful) {
//        this.successful = successful;
//    }
//}
