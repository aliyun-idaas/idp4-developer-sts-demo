package stsdemo.idsmanager.com.stsdemo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.idsmanager.stslibrary.STS;
import com.idsmanager.stslibrary.callback.TokenCallBack;

import butterknife.Bind;
import butterknife.ButterKnife;
import stsdemo.idsmanager.com.stsdemo.view.MyNormalActionBar;

public class MainActivity extends BaseActivity {
    private static final String TAG = "MainActivity";
    private String idToken;
    private String headUrl;
    private String username;
    private String refreshToken;
    private Intent intent;
    @Bind(R.id.tv_show_id_token)
    TextView tvShowIdToken;
    @Bind(R.id.my_top_bar)
    MyNormalActionBar mTopBar;
    @Bind(R.id.btn_refresh_id_token)
    Button btnRefreshIdToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initView();
        intent = getIntent();
        idToken = intent.getStringExtra("id_token");
        headUrl = intent.getStringExtra("head_url");
        username = intent.getStringExtra("username");
        refreshToken = intent.getStringExtra("refreshToken");
        tvShowIdToken.setText(idToken + "");
    }

    private void initView() {
        mTopBar.setVisibility(View.VISIBLE);
        mTopBar.setCenterStr("获取Token");
        mTopBar.setLeftRes(R.drawable.ba_back);
        mTopBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                switch (id) {
                    case R.id.btn_actionbar_left:
                    case R.id.ll_actionbar_left:
                        finish();
                        break;
                    default:
                        break;
                }
            }
        });
        btnRefreshIdToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                STS.getInstance().refreshIdToken(headUrl, refreshToken, username, new TokenCallBack() {
                    @Override
                    public String onGetToken(final String idToken, String refreshToken) {
                        Log.d(TAG, "idToken-->" + idToken );
                        Log.d(TAG, "refreshToken=" + refreshToken);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dismissLoading();
                                tvShowIdToken.setText(idToken);
                            }
                        });
                        return null;
                    }

                    @Override
                    public void onError(int errorCode) {
                        Log.d(TAG, "errorCode-->" + errorCode);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dismissLoading();
                            }
                        });
                    }

                });
            }
        });
    }
}
