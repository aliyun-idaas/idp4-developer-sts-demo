package stsdemo.idsmanager.com.stsdemo;//package stsdemo.idsmanager.com.stsdemoapplication;
//
///**
// * describe
// * Created by hui on 2017/5/24.
// */
//
//public class NetUtil {
//    public static String BASE_URL = "https://jzyt.idp.idsmanager.com:8040";
//    public static String GET_ID_TOKEN = "/api/public/sts/retrieve_id_token";
//}
