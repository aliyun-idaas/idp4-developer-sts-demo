package stsdemo.idsmanager.com.stsdemo.request;//package stsdemo.idsmanager.com.stsdemoapplication.request;
//
///**
// * describe
// * Created by hui on 2017/5/24.
// */
//
//public class IdTokenBean {
//    private String appKey;
//    private String appSecret;
//    private String username;
//    private String password;
//
//    public IdTokenBean(String appKey, String appSecret, String username, String password) {
//        this.appKey = appKey;
//        this.appSecret = appSecret;
//        this.username = username;
//        this.password = password;
//    }
//}
