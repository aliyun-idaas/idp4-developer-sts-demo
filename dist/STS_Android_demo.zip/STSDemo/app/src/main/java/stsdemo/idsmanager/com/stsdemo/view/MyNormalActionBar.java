package stsdemo.idsmanager.com.stsdemo.view;


import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import stsdemo.idsmanager.com.stsdemo.R;


public class MyNormalActionBar extends LinearLayout implements OnClickListener {

    private Context context;
    private ImageView btn_left;
    private ImageView btn_right;
    private TextView tv_title;
    private OnClickListener listener;
    private TextView mTvLeft;
    private TextView mTvRight;
    private LinearLayout llActionbarLeft;


    public MyNormalActionBar(Context context) {
        this(context, null);
    }

    public MyNormalActionBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        LayoutInflater.from(context).inflate(R.layout.actionbar_lay, this, true);
        init();
    }

    private void init() {
        btn_left = (ImageView) findViewById(R.id.btn_actionbar_left);
        btn_right = (ImageView) findViewById(R.id.img_actionbar_right);
        tv_title = (TextView) findViewById(R.id.tv_actionbar_center);
        mTvLeft = (TextView) findViewById(R.id.tv_actionbar_left);
        mTvRight = (TextView) findViewById(R.id.tv_right);
        llActionbarLeft = (LinearLayout) findViewById(R.id.ll_actionbar_left);
        llActionbarLeft.setOnClickListener(this);
        mTvRight.setOnClickListener(this);
        btn_left.setOnClickListener(this);
        btn_right.setOnClickListener(this);
        tv_title.setOnClickListener(this);
    }


    /**
     * 设置左边按钮资源图片
     *
     * @param res
     */
    public void setLeftRes(int res) {
        btn_left.setBackgroundResource(res);
    }

    public void setLeftResView(boolean is_show) {
        if(!is_show){
            btn_left.setVisibility(GONE);
        }
    }
    /**
     * 设置左边文字
     *
     * @param str
     */
    public void setLeftStr(String str) {
        mTvLeft.setText(str);
    }

    /**
     * 设置中间按钮资源图片
     *
     * @param
     */
    public void setCenterTitle(String str) {
        tv_title.setText(str);
    }
    /**
     * 设置中间按钮资源图片
     *
     * @param
     */
    public void setCenterRes(int res) {
        tv_title.setBackgroundResource(res);
    }
    /**
     * 设置中间按钮资源图片
     *
     * @param
     */
    public void setCenterStr(String str) {
        tv_title.setText(str);
    }


    /**
     * 设置右边按钮资源图片
     *
     * @param res
     */
    public void setRightRes(int res) {
//        btn_right.setBackgroundResource(res);
        btn_right.setImageResource(res);
    }

    /**
     * 设置右边文字
     *
     * @param
     */
    public void setRightStr(String str) {
        mTvRight.setVisibility(View.GONE);
        btn_right.setVisibility(View.VISIBLE);
//        btn_right.setText(str);
    }

    /**
     * 设置右边文字颜色
     *
     * @param
     */
    public void setRightStrColor(int i) {
        mTvRight.setVisibility(View.GONE);
        btn_right.setVisibility(View.VISIBLE);
//        btn_right.setTextColor(i);
    }

    /**
     * 设置右边文字
     *
     * @param
     */
    public void setTVRightStr(String str) {
        btn_right.setVisibility(View.GONE);
        mTvRight.setVisibility(View.VISIBLE);
        mTvRight.setText(str);
    }

    /**
     * 设置右边文字颜色
     *
     * @param
     */
    public void setTVRightStrColor(int i) {
        btn_right.setVisibility(View.GONE);
        mTvRight.setVisibility(View.VISIBLE);
        mTvRight.setTextColor(i);
    }

    /**
     * 取消显示右边按钮
     */
    public void setRightNone() {
        btn_right.setVisibility(View.GONE);
    }

    @Override
    public void setOnClickListener(OnClickListener l) {
        this.listener = l;
    }

    public void onClick(View v) {
        if (listener != null) {
            listener.onClick(v);
        }
    }

}
