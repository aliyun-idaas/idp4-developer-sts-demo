package stsdemo.idsmanager.com.stsdemo.response;//package stsdemo.idsmanager.com.stsdemoapplication.response;
//
///**
// * describe
// * Created by hui on 2017/5/24.
// */
//
//public class IdTokenResponse extends BaseResponse {
//    private String id_token;
//
//    public IdTokenResponse(int statusCode, String[] errors, boolean successful, String id_token) {
//        super(statusCode, errors, successful);
//        this.id_token = id_token;
//    }
//
//    public String getId_token() {
//        return id_token;
//    }
//
//    public void setId_token(String id_token) {
//        this.id_token = id_token;
//    }
//}
